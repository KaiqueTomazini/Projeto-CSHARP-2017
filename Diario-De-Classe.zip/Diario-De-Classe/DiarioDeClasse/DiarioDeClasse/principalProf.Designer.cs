﻿namespace DiarioDeClasse
{
    partial class principalProf
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl45 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl40 = new System.Windows.Forms.Label();
            this.lbl39 = new System.Windows.Forms.Label();
            this.lbl38 = new System.Windows.Forms.Label();
            this.lbl37 = new System.Windows.Forms.Label();
            this.lblSexta = new System.Windows.Forms.Label();
            this.lbl36 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl29 = new System.Windows.Forms.Label();
            this.lbl28 = new System.Windows.Forms.Label();
            this.lblQuinta = new System.Windows.Forms.Label();
            this.lbl27 = new System.Windows.Forms.Label();
            this.lbl26 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl19 = new System.Windows.Forms.Label();
            this.lblQuarta = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lblTerça = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lblSegunda = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl45
            // 
            this.lbl45.BackColor = System.Drawing.Color.Transparent;
            this.lbl45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl45.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl45.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl45.Location = new System.Drawing.Point(532, 503);
            this.lbl45.Margin = new System.Windows.Forms.Padding(0);
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(133, 54);
            this.lbl45.TabIndex = 159;
            this.lbl45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl44
            // 
            this.lbl44.BackColor = System.Drawing.Color.Transparent;
            this.lbl44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl44.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl44.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl44.Location = new System.Drawing.Point(532, 449);
            this.lbl44.Margin = new System.Windows.Forms.Padding(0);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(133, 54);
            this.lbl44.TabIndex = 158;
            this.lbl44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl43
            // 
            this.lbl43.BackColor = System.Drawing.Color.Transparent;
            this.lbl43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl43.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl43.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl43.Location = new System.Drawing.Point(532, 395);
            this.lbl43.Margin = new System.Windows.Forms.Padding(0);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(133, 54);
            this.lbl43.TabIndex = 157;
            this.lbl43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl42
            // 
            this.lbl42.BackColor = System.Drawing.Color.Transparent;
            this.lbl42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl42.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl42.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl42.Location = new System.Drawing.Point(532, 341);
            this.lbl42.Margin = new System.Windows.Forms.Padding(0);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(133, 54);
            this.lbl42.TabIndex = 156;
            this.lbl42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl41
            // 
            this.lbl41.BackColor = System.Drawing.Color.Transparent;
            this.lbl41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl41.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl41.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl41.Location = new System.Drawing.Point(532, 287);
            this.lbl41.Margin = new System.Windows.Forms.Padding(0);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(133, 54);
            this.lbl41.TabIndex = 155;
            this.lbl41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl40
            // 
            this.lbl40.BackColor = System.Drawing.Color.Transparent;
            this.lbl40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl40.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl40.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl40.Location = new System.Drawing.Point(532, 233);
            this.lbl40.Margin = new System.Windows.Forms.Padding(0);
            this.lbl40.Name = "lbl40";
            this.lbl40.Size = new System.Drawing.Size(133, 54);
            this.lbl40.TabIndex = 154;
            this.lbl40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl39
            // 
            this.lbl39.BackColor = System.Drawing.Color.Transparent;
            this.lbl39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl39.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl39.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl39.Location = new System.Drawing.Point(532, 179);
            this.lbl39.Margin = new System.Windows.Forms.Padding(0);
            this.lbl39.Name = "lbl39";
            this.lbl39.Size = new System.Drawing.Size(133, 54);
            this.lbl39.TabIndex = 153;
            this.lbl39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl38
            // 
            this.lbl38.BackColor = System.Drawing.Color.Transparent;
            this.lbl38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl38.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl38.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl38.Location = new System.Drawing.Point(532, 125);
            this.lbl38.Margin = new System.Windows.Forms.Padding(0);
            this.lbl38.Name = "lbl38";
            this.lbl38.Size = new System.Drawing.Size(133, 54);
            this.lbl38.TabIndex = 152;
            this.lbl38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl37
            // 
            this.lbl37.BackColor = System.Drawing.Color.Transparent;
            this.lbl37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl37.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl37.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl37.Location = new System.Drawing.Point(532, 71);
            this.lbl37.Margin = new System.Windows.Forms.Padding(0);
            this.lbl37.Name = "lbl37";
            this.lbl37.Size = new System.Drawing.Size(133, 54);
            this.lbl37.TabIndex = 151;
            this.lbl37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSexta
            // 
            this.lblSexta.BackColor = System.Drawing.Color.Transparent;
            this.lblSexta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSexta.Font = new System.Drawing.Font("Courier New", 15F);
            this.lblSexta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(204)))));
            this.lblSexta.Location = new System.Drawing.Point(532, 42);
            this.lblSexta.Margin = new System.Windows.Forms.Padding(0);
            this.lblSexta.Name = "lblSexta";
            this.lblSexta.Size = new System.Drawing.Size(133, 29);
            this.lblSexta.TabIndex = 150;
            this.lblSexta.Text = "SEXTA";
            this.lblSexta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl36
            // 
            this.lbl36.BackColor = System.Drawing.Color.Transparent;
            this.lbl36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl36.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl36.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl36.Location = new System.Drawing.Point(399, 503);
            this.lbl36.Margin = new System.Windows.Forms.Padding(0);
            this.lbl36.Name = "lbl36";
            this.lbl36.Size = new System.Drawing.Size(133, 54);
            this.lbl36.TabIndex = 149;
            this.lbl36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl35
            // 
            this.lbl35.BackColor = System.Drawing.Color.Transparent;
            this.lbl35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl35.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl35.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl35.Location = new System.Drawing.Point(399, 449);
            this.lbl35.Margin = new System.Windows.Forms.Padding(0);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(133, 54);
            this.lbl35.TabIndex = 148;
            this.lbl35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl34
            // 
            this.lbl34.BackColor = System.Drawing.Color.Transparent;
            this.lbl34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl34.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl34.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl34.Location = new System.Drawing.Point(399, 395);
            this.lbl34.Margin = new System.Windows.Forms.Padding(0);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(133, 54);
            this.lbl34.TabIndex = 147;
            this.lbl34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl33
            // 
            this.lbl33.BackColor = System.Drawing.Color.Transparent;
            this.lbl33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl33.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl33.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl33.Location = new System.Drawing.Point(399, 341);
            this.lbl33.Margin = new System.Windows.Forms.Padding(0);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(133, 54);
            this.lbl33.TabIndex = 146;
            this.lbl33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl32
            // 
            this.lbl32.BackColor = System.Drawing.Color.Transparent;
            this.lbl32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl32.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl32.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl32.Location = new System.Drawing.Point(399, 287);
            this.lbl32.Margin = new System.Windows.Forms.Padding(0);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(133, 54);
            this.lbl32.TabIndex = 145;
            this.lbl32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl31
            // 
            this.lbl31.BackColor = System.Drawing.Color.Transparent;
            this.lbl31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl31.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl31.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl31.Location = new System.Drawing.Point(399, 233);
            this.lbl31.Margin = new System.Windows.Forms.Padding(0);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(133, 54);
            this.lbl31.TabIndex = 144;
            this.lbl31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl30
            // 
            this.lbl30.BackColor = System.Drawing.Color.Transparent;
            this.lbl30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl30.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl30.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl30.Location = new System.Drawing.Point(399, 179);
            this.lbl30.Margin = new System.Windows.Forms.Padding(0);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(133, 54);
            this.lbl30.TabIndex = 143;
            this.lbl30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl29
            // 
            this.lbl29.BackColor = System.Drawing.Color.Transparent;
            this.lbl29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl29.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl29.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl29.Location = new System.Drawing.Point(399, 125);
            this.lbl29.Margin = new System.Windows.Forms.Padding(0);
            this.lbl29.Name = "lbl29";
            this.lbl29.Size = new System.Drawing.Size(133, 54);
            this.lbl29.TabIndex = 142;
            this.lbl29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl28
            // 
            this.lbl28.BackColor = System.Drawing.Color.Transparent;
            this.lbl28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl28.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl28.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl28.Location = new System.Drawing.Point(399, 71);
            this.lbl28.Margin = new System.Windows.Forms.Padding(0);
            this.lbl28.Name = "lbl28";
            this.lbl28.Size = new System.Drawing.Size(133, 54);
            this.lbl28.TabIndex = 141;
            this.lbl28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuinta
            // 
            this.lblQuinta.BackColor = System.Drawing.Color.Transparent;
            this.lblQuinta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblQuinta.Font = new System.Drawing.Font("Courier New", 15F);
            this.lblQuinta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(204)))));
            this.lblQuinta.Location = new System.Drawing.Point(399, 42);
            this.lblQuinta.Margin = new System.Windows.Forms.Padding(0);
            this.lblQuinta.Name = "lblQuinta";
            this.lblQuinta.Size = new System.Drawing.Size(133, 29);
            this.lblQuinta.TabIndex = 140;
            this.lblQuinta.Text = "QUINTA";
            this.lblQuinta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl27
            // 
            this.lbl27.BackColor = System.Drawing.Color.Transparent;
            this.lbl27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl27.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl27.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl27.Location = new System.Drawing.Point(266, 503);
            this.lbl27.Margin = new System.Windows.Forms.Padding(0);
            this.lbl27.Name = "lbl27";
            this.lbl27.Size = new System.Drawing.Size(133, 54);
            this.lbl27.TabIndex = 139;
            this.lbl27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl26
            // 
            this.lbl26.BackColor = System.Drawing.Color.Transparent;
            this.lbl26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl26.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl26.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl26.Location = new System.Drawing.Point(266, 449);
            this.lbl26.Margin = new System.Windows.Forms.Padding(0);
            this.lbl26.Name = "lbl26";
            this.lbl26.Size = new System.Drawing.Size(133, 54);
            this.lbl26.TabIndex = 138;
            this.lbl26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl25
            // 
            this.lbl25.BackColor = System.Drawing.Color.Transparent;
            this.lbl25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl25.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl25.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl25.Location = new System.Drawing.Point(266, 395);
            this.lbl25.Margin = new System.Windows.Forms.Padding(0);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(133, 54);
            this.lbl25.TabIndex = 137;
            this.lbl25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl24
            // 
            this.lbl24.BackColor = System.Drawing.Color.Transparent;
            this.lbl24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl24.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl24.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl24.Location = new System.Drawing.Point(266, 341);
            this.lbl24.Margin = new System.Windows.Forms.Padding(0);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(133, 54);
            this.lbl24.TabIndex = 136;
            this.lbl24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl23
            // 
            this.lbl23.BackColor = System.Drawing.Color.Transparent;
            this.lbl23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl23.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl23.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl23.Location = new System.Drawing.Point(266, 287);
            this.lbl23.Margin = new System.Windows.Forms.Padding(0);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(133, 54);
            this.lbl23.TabIndex = 135;
            this.lbl23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.Transparent;
            this.lbl22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl22.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl22.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl22.Location = new System.Drawing.Point(266, 233);
            this.lbl22.Margin = new System.Windows.Forms.Padding(0);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(133, 54);
            this.lbl22.TabIndex = 134;
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.Transparent;
            this.lbl21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl21.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl21.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl21.Location = new System.Drawing.Point(266, 179);
            this.lbl21.Margin = new System.Windows.Forms.Padding(0);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(133, 54);
            this.lbl21.TabIndex = 133;
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl20
            // 
            this.lbl20.BackColor = System.Drawing.Color.Transparent;
            this.lbl20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl20.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl20.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl20.Location = new System.Drawing.Point(266, 125);
            this.lbl20.Margin = new System.Windows.Forms.Padding(0);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(133, 54);
            this.lbl20.TabIndex = 132;
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl19
            // 
            this.lbl19.BackColor = System.Drawing.Color.Transparent;
            this.lbl19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl19.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl19.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl19.Location = new System.Drawing.Point(266, 71);
            this.lbl19.Margin = new System.Windows.Forms.Padding(0);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(133, 54);
            this.lbl19.TabIndex = 131;
            this.lbl19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblQuarta
            // 
            this.lblQuarta.BackColor = System.Drawing.Color.Transparent;
            this.lblQuarta.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblQuarta.Font = new System.Drawing.Font("Courier New", 15F);
            this.lblQuarta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(204)))));
            this.lblQuarta.Location = new System.Drawing.Point(266, 42);
            this.lblQuarta.Margin = new System.Windows.Forms.Padding(0);
            this.lblQuarta.Name = "lblQuarta";
            this.lblQuarta.Size = new System.Drawing.Size(133, 29);
            this.lblQuarta.TabIndex = 130;
            this.lblQuarta.Text = "QUARTA";
            this.lblQuarta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl18
            // 
            this.lbl18.BackColor = System.Drawing.Color.Transparent;
            this.lbl18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl18.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl18.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl18.Location = new System.Drawing.Point(133, 503);
            this.lbl18.Margin = new System.Windows.Forms.Padding(0);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(133, 54);
            this.lbl18.TabIndex = 129;
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl17
            // 
            this.lbl17.BackColor = System.Drawing.Color.Transparent;
            this.lbl17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl17.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl17.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl17.Location = new System.Drawing.Point(133, 449);
            this.lbl17.Margin = new System.Windows.Forms.Padding(0);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(133, 54);
            this.lbl17.TabIndex = 128;
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl16
            // 
            this.lbl16.BackColor = System.Drawing.Color.Transparent;
            this.lbl16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl16.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl16.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl16.Location = new System.Drawing.Point(133, 395);
            this.lbl16.Margin = new System.Windows.Forms.Padding(0);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(133, 54);
            this.lbl16.TabIndex = 127;
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl15
            // 
            this.lbl15.BackColor = System.Drawing.Color.Transparent;
            this.lbl15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl15.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl15.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl15.Location = new System.Drawing.Point(133, 341);
            this.lbl15.Margin = new System.Windows.Forms.Padding(0);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(133, 54);
            this.lbl15.TabIndex = 126;
            this.lbl15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl14
            // 
            this.lbl14.BackColor = System.Drawing.Color.Transparent;
            this.lbl14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl14.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl14.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl14.Location = new System.Drawing.Point(133, 287);
            this.lbl14.Margin = new System.Windows.Forms.Padding(0);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(133, 54);
            this.lbl14.TabIndex = 125;
            this.lbl14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl13
            // 
            this.lbl13.BackColor = System.Drawing.Color.Transparent;
            this.lbl13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl13.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl13.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl13.Location = new System.Drawing.Point(133, 233);
            this.lbl13.Margin = new System.Windows.Forms.Padding(0);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(133, 54);
            this.lbl13.TabIndex = 124;
            this.lbl13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.Transparent;
            this.lbl12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl12.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl12.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl12.Location = new System.Drawing.Point(133, 179);
            this.lbl12.Margin = new System.Windows.Forms.Padding(0);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(133, 54);
            this.lbl12.TabIndex = 123;
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.Transparent;
            this.lbl11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl11.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl11.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl11.Location = new System.Drawing.Point(133, 125);
            this.lbl11.Margin = new System.Windows.Forms.Padding(0);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(133, 54);
            this.lbl11.TabIndex = 122;
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl10
            // 
            this.lbl10.BackColor = System.Drawing.Color.Transparent;
            this.lbl10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl10.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl10.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl10.Location = new System.Drawing.Point(133, 71);
            this.lbl10.Margin = new System.Windows.Forms.Padding(0);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(133, 54);
            this.lbl10.TabIndex = 121;
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTerça
            // 
            this.lblTerça.BackColor = System.Drawing.Color.Transparent;
            this.lblTerça.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTerça.Font = new System.Drawing.Font("Courier New", 15F);
            this.lblTerça.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(204)))));
            this.lblTerça.Location = new System.Drawing.Point(133, 42);
            this.lblTerça.Margin = new System.Windows.Forms.Padding(0);
            this.lblTerça.Name = "lblTerça";
            this.lblTerça.Size = new System.Drawing.Size(133, 29);
            this.lblTerça.TabIndex = 120;
            this.lblTerça.Text = "TERÇA";
            this.lblTerça.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl9
            // 
            this.lbl9.BackColor = System.Drawing.Color.Transparent;
            this.lbl9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl9.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl9.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl9.Location = new System.Drawing.Point(0, 503);
            this.lbl9.Margin = new System.Windows.Forms.Padding(0);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(133, 54);
            this.lbl9.TabIndex = 119;
            this.lbl9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl8
            // 
            this.lbl8.BackColor = System.Drawing.Color.Transparent;
            this.lbl8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl8.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl8.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl8.Location = new System.Drawing.Point(0, 449);
            this.lbl8.Margin = new System.Windows.Forms.Padding(0);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(133, 54);
            this.lbl8.TabIndex = 118;
            this.lbl8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl7
            // 
            this.lbl7.BackColor = System.Drawing.Color.Transparent;
            this.lbl7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl7.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl7.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl7.Location = new System.Drawing.Point(0, 395);
            this.lbl7.Margin = new System.Windows.Forms.Padding(0);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(133, 54);
            this.lbl7.TabIndex = 117;
            this.lbl7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl6
            // 
            this.lbl6.BackColor = System.Drawing.Color.Transparent;
            this.lbl6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl6.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl6.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl6.Location = new System.Drawing.Point(0, 341);
            this.lbl6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(133, 54);
            this.lbl6.TabIndex = 116;
            this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl5
            // 
            this.lbl5.BackColor = System.Drawing.Color.Transparent;
            this.lbl5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl5.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl5.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl5.Location = new System.Drawing.Point(0, 287);
            this.lbl5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(133, 54);
            this.lbl5.TabIndex = 115;
            this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl4
            // 
            this.lbl4.BackColor = System.Drawing.Color.Transparent;
            this.lbl4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl4.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl4.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl4.Location = new System.Drawing.Point(0, 233);
            this.lbl4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(133, 54);
            this.lbl4.TabIndex = 114;
            this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl3
            // 
            this.lbl3.BackColor = System.Drawing.Color.Transparent;
            this.lbl3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl3.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl3.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl3.Location = new System.Drawing.Point(0, 179);
            this.lbl3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(133, 54);
            this.lbl3.TabIndex = 113;
            this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl2
            // 
            this.lbl2.BackColor = System.Drawing.Color.Transparent;
            this.lbl2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl2.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl2.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl2.Location = new System.Drawing.Point(0, 125);
            this.lbl2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(133, 54);
            this.lbl2.TabIndex = 112;
            this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl1
            // 
            this.lbl1.BackColor = System.Drawing.Color.Transparent;
            this.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl1.Font = new System.Drawing.Font("Courier New", 8F);
            this.lbl1.ForeColor = System.Drawing.Color.MediumBlue;
            this.lbl1.Location = new System.Drawing.Point(0, 71);
            this.lbl1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(133, 54);
            this.lbl1.TabIndex = 111;
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSegunda
            // 
            this.lblSegunda.BackColor = System.Drawing.Color.Transparent;
            this.lblSegunda.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSegunda.Font = new System.Drawing.Font("Courier New", 15F);
            this.lblSegunda.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(237)))), ((int)(((byte)(204)))));
            this.lblSegunda.Location = new System.Drawing.Point(0, 42);
            this.lblSegunda.Margin = new System.Windows.Forms.Padding(0);
            this.lblSegunda.Name = "lblSegunda";
            this.lblSegunda.Size = new System.Drawing.Size(133, 29);
            this.lblSegunda.TabIndex = 110;
            this.lblSegunda.Text = "SEGUNDA";
            this.lblSegunda.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Trajan Pro", 24F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(659, 42);
            this.label1.TabIndex = 160;
            this.label1.Text = "Horário de aulas:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // principalProf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl40);
            this.Controls.Add(this.lbl39);
            this.Controls.Add(this.lbl38);
            this.Controls.Add(this.lbl37);
            this.Controls.Add(this.lblSexta);
            this.Controls.Add(this.lbl36);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl30);
            this.Controls.Add(this.lbl29);
            this.Controls.Add(this.lbl28);
            this.Controls.Add(this.lblQuinta);
            this.Controls.Add(this.lbl27);
            this.Controls.Add(this.lbl26);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl20);
            this.Controls.Add(this.lbl19);
            this.Controls.Add(this.lblQuarta);
            this.Controls.Add(this.lbl18);
            this.Controls.Add(this.lbl17);
            this.Controls.Add(this.lbl16);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lblTerça);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lblSegunda);
            this.Name = "principalProf";
            this.Size = new System.Drawing.Size(665, 560);
            this.Load += new System.EventHandler(this.frmPrincipal_Shown);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl45;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl43;
        private System.Windows.Forms.Label lbl42;
        private System.Windows.Forms.Label lbl41;
        private System.Windows.Forms.Label lbl40;
        private System.Windows.Forms.Label lbl39;
        private System.Windows.Forms.Label lbl38;
        private System.Windows.Forms.Label lbl37;
        private System.Windows.Forms.Label lblSexta;
        private System.Windows.Forms.Label lbl36;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl29;
        private System.Windows.Forms.Label lbl28;
        private System.Windows.Forms.Label lblQuinta;
        private System.Windows.Forms.Label lbl27;
        private System.Windows.Forms.Label lbl26;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl19;
        private System.Windows.Forms.Label lblQuarta;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lblTerça;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lblSegunda;
        private System.Windows.Forms.Label label1;
    }
}
