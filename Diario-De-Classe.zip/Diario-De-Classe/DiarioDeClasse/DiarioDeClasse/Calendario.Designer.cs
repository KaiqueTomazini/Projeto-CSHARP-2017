﻿namespace DiarioDeClasse
{
    partial class Calendario
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calendario));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel38 = new System.Windows.Forms.TableLayoutPanel();
            this.ad35 = new System.Windows.Forms.Label();
            this.a35 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel37 = new System.Windows.Forms.TableLayoutPanel();
            this.ad34 = new System.Windows.Forms.Label();
            this.a34 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel36 = new System.Windows.Forms.TableLayoutPanel();
            this.ad33 = new System.Windows.Forms.Label();
            this.a33 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel35 = new System.Windows.Forms.TableLayoutPanel();
            this.ad32 = new System.Windows.Forms.Label();
            this.a32 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel34 = new System.Windows.Forms.TableLayoutPanel();
            this.ad31 = new System.Windows.Forms.Label();
            this.a31 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel33 = new System.Windows.Forms.TableLayoutPanel();
            this.ad30 = new System.Windows.Forms.Label();
            this.a30 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel32 = new System.Windows.Forms.TableLayoutPanel();
            this.ad29 = new System.Windows.Forms.Label();
            this.a29 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel31 = new System.Windows.Forms.TableLayoutPanel();
            this.ad28 = new System.Windows.Forms.Label();
            this.a28 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel30 = new System.Windows.Forms.TableLayoutPanel();
            this.ad27 = new System.Windows.Forms.Label();
            this.a27 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel29 = new System.Windows.Forms.TableLayoutPanel();
            this.ad26 = new System.Windows.Forms.Label();
            this.a26 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel28 = new System.Windows.Forms.TableLayoutPanel();
            this.ad25 = new System.Windows.Forms.Label();
            this.a25 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel27 = new System.Windows.Forms.TableLayoutPanel();
            this.ad24 = new System.Windows.Forms.Label();
            this.a24 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel26 = new System.Windows.Forms.TableLayoutPanel();
            this.ad23 = new System.Windows.Forms.Label();
            this.a23 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel25 = new System.Windows.Forms.TableLayoutPanel();
            this.ad22 = new System.Windows.Forms.Label();
            this.a22 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel24 = new System.Windows.Forms.TableLayoutPanel();
            this.ad21 = new System.Windows.Forms.Label();
            this.a21 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel23 = new System.Windows.Forms.TableLayoutPanel();
            this.ad20 = new System.Windows.Forms.Label();
            this.a20 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel22 = new System.Windows.Forms.TableLayoutPanel();
            this.ad19 = new System.Windows.Forms.Label();
            this.a19 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel21 = new System.Windows.Forms.TableLayoutPanel();
            this.ad18 = new System.Windows.Forms.Label();
            this.a18 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel20 = new System.Windows.Forms.TableLayoutPanel();
            this.ad17 = new System.Windows.Forms.Label();
            this.a17 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel19 = new System.Windows.Forms.TableLayoutPanel();
            this.ad16 = new System.Windows.Forms.Label();
            this.a16 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel18 = new System.Windows.Forms.TableLayoutPanel();
            this.ad15 = new System.Windows.Forms.Label();
            this.a15 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel17 = new System.Windows.Forms.TableLayoutPanel();
            this.ad14 = new System.Windows.Forms.Label();
            this.a14 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel16 = new System.Windows.Forms.TableLayoutPanel();
            this.ad13 = new System.Windows.Forms.Label();
            this.a13 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.ad12 = new System.Windows.Forms.Label();
            this.a12 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.ad11 = new System.Windows.Forms.Label();
            this.a11 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.ad10 = new System.Windows.Forms.Label();
            this.a10 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.ad9 = new System.Windows.Forms.Label();
            this.a9 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.ad8 = new System.Windows.Forms.Label();
            this.a8 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.ad7 = new System.Windows.Forms.Label();
            this.a7 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.ad6 = new System.Windows.Forms.Label();
            this.a6 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.ad5 = new System.Windows.Forms.Label();
            this.a5 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.ad4 = new System.Windows.Forms.Label();
            this.a4 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.ad3 = new System.Windows.Forms.Label();
            this.a3 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.ad2 = new System.Windows.Forms.Label();
            this.a2 = new System.Windows.Forms.FlowLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.ad1 = new System.Windows.Forms.Label();
            this.a1 = new System.Windows.Forms.FlowLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel38.SuspendLayout();
            this.tableLayoutPanel37.SuspendLayout();
            this.tableLayoutPanel36.SuspendLayout();
            this.tableLayoutPanel35.SuspendLayout();
            this.tableLayoutPanel34.SuspendLayout();
            this.tableLayoutPanel33.SuspendLayout();
            this.tableLayoutPanel32.SuspendLayout();
            this.tableLayoutPanel31.SuspendLayout();
            this.tableLayoutPanel30.SuspendLayout();
            this.tableLayoutPanel29.SuspendLayout();
            this.tableLayoutPanel28.SuspendLayout();
            this.tableLayoutPanel27.SuspendLayout();
            this.tableLayoutPanel26.SuspendLayout();
            this.tableLayoutPanel25.SuspendLayout();
            this.tableLayoutPanel24.SuspendLayout();
            this.tableLayoutPanel23.SuspendLayout();
            this.tableLayoutPanel22.SuspendLayout();
            this.tableLayoutPanel21.SuspendLayout();
            this.tableLayoutPanel20.SuspendLayout();
            this.tableLayoutPanel19.SuspendLayout();
            this.tableLayoutPanel18.SuspendLayout();
            this.tableLayoutPanel17.SuspendLayout();
            this.tableLayoutPanel16.SuspendLayout();
            this.tableLayoutPanel15.SuspendLayout();
            this.tableLayoutPanel14.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(665, 560);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel38, 6, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel37, 5, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel36, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel35, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel34, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel33, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel32, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel31, 6, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel30, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel29, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel28, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel27, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel26, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel25, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel24, 6, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel23, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel22, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel21, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel20, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel19, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel18, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel17, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel16, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel15, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel14, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel13, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel12, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel11, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel10, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel9, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel8, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label7, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 20);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0, 20, 0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(665, 484);
            this.tableLayoutPanel2.TabIndex = 0;
            this.tableLayoutPanel2.Resize += new System.EventHandler(this.tableLayoutPanel2_Resize);
            // 
            // tableLayoutPanel38
            // 
            this.tableLayoutPanel38.ColumnCount = 1;
            this.tableLayoutPanel38.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel38.Controls.Add(this.ad35, 0, 0);
            this.tableLayoutPanel38.Controls.Add(this.a35, 0, 1);
            this.tableLayoutPanel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel38.Location = new System.Drawing.Point(564, 396);
            this.tableLayoutPanel38.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel38.Name = "tableLayoutPanel38";
            this.tableLayoutPanel38.RowCount = 2;
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel38.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel38.Size = new System.Drawing.Size(101, 88);
            this.tableLayoutPanel38.TabIndex = 135;
            // 
            // ad35
            // 
            this.ad35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad35.Location = new System.Drawing.Point(0, 0);
            this.ad35.Margin = new System.Windows.Forms.Padding(0);
            this.ad35.Name = "ad35";
            this.ad35.Size = new System.Drawing.Size(101, 17);
            this.ad35.TabIndex = 0;
            this.ad35.Click += new System.EventHandler(this.a30_Click);
            // 
            // a35
            // 
            this.a35.AutoScroll = true;
            this.a35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a35.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a35.Location = new System.Drawing.Point(0, 17);
            this.a35.Margin = new System.Windows.Forms.Padding(0);
            this.a35.Name = "a35";
            this.a35.Size = new System.Drawing.Size(101, 71);
            this.a35.TabIndex = 1;
            this.a35.WrapContents = false;
            this.a35.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel37
            // 
            this.tableLayoutPanel37.ColumnCount = 1;
            this.tableLayoutPanel37.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel37.Controls.Add(this.ad34, 0, 0);
            this.tableLayoutPanel37.Controls.Add(this.a34, 0, 1);
            this.tableLayoutPanel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel37.Location = new System.Drawing.Point(470, 396);
            this.tableLayoutPanel37.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel37.Name = "tableLayoutPanel37";
            this.tableLayoutPanel37.RowCount = 2;
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel37.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel37.Size = new System.Drawing.Size(94, 88);
            this.tableLayoutPanel37.TabIndex = 134;
            // 
            // ad34
            // 
            this.ad34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad34.Location = new System.Drawing.Point(0, 0);
            this.ad34.Margin = new System.Windows.Forms.Padding(0);
            this.ad34.Name = "ad34";
            this.ad34.Size = new System.Drawing.Size(94, 17);
            this.ad34.TabIndex = 0;
            this.ad34.Click += new System.EventHandler(this.a30_Click);
            // 
            // a34
            // 
            this.a34.AutoScroll = true;
            this.a34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a34.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a34.Location = new System.Drawing.Point(0, 17);
            this.a34.Margin = new System.Windows.Forms.Padding(0);
            this.a34.Name = "a34";
            this.a34.Size = new System.Drawing.Size(94, 71);
            this.a34.TabIndex = 1;
            this.a34.WrapContents = false;
            this.a34.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel36
            // 
            this.tableLayoutPanel36.ColumnCount = 1;
            this.tableLayoutPanel36.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel36.Controls.Add(this.ad33, 0, 0);
            this.tableLayoutPanel36.Controls.Add(this.a33, 0, 1);
            this.tableLayoutPanel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel36.Location = new System.Drawing.Point(376, 396);
            this.tableLayoutPanel36.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel36.Name = "tableLayoutPanel36";
            this.tableLayoutPanel36.RowCount = 2;
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel36.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel36.Size = new System.Drawing.Size(94, 88);
            this.tableLayoutPanel36.TabIndex = 133;
            this.tableLayoutPanel36.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel36_Paint);
            // 
            // ad33
            // 
            this.ad33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad33.Location = new System.Drawing.Point(0, 0);
            this.ad33.Margin = new System.Windows.Forms.Padding(0);
            this.ad33.Name = "ad33";
            this.ad33.Size = new System.Drawing.Size(94, 17);
            this.ad33.TabIndex = 0;
            this.ad33.Click += new System.EventHandler(this.a30_Click);
            // 
            // a33
            // 
            this.a33.AutoScroll = true;
            this.a33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a33.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a33.Location = new System.Drawing.Point(0, 17);
            this.a33.Margin = new System.Windows.Forms.Padding(0);
            this.a33.Name = "a33";
            this.a33.Size = new System.Drawing.Size(94, 71);
            this.a33.TabIndex = 1;
            this.a33.WrapContents = false;
            this.a33.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel35
            // 
            this.tableLayoutPanel35.ColumnCount = 1;
            this.tableLayoutPanel35.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel35.Controls.Add(this.ad32, 0, 0);
            this.tableLayoutPanel35.Controls.Add(this.a32, 0, 1);
            this.tableLayoutPanel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel35.Location = new System.Drawing.Point(282, 396);
            this.tableLayoutPanel35.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel35.Name = "tableLayoutPanel35";
            this.tableLayoutPanel35.RowCount = 2;
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel35.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel35.Size = new System.Drawing.Size(94, 88);
            this.tableLayoutPanel35.TabIndex = 132;
            // 
            // ad32
            // 
            this.ad32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad32.Location = new System.Drawing.Point(0, 0);
            this.ad32.Margin = new System.Windows.Forms.Padding(0);
            this.ad32.Name = "ad32";
            this.ad32.Size = new System.Drawing.Size(94, 17);
            this.ad32.TabIndex = 0;
            this.ad32.Click += new System.EventHandler(this.a30_Click);
            // 
            // a32
            // 
            this.a32.AutoScroll = true;
            this.a32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a32.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a32.Location = new System.Drawing.Point(0, 17);
            this.a32.Margin = new System.Windows.Forms.Padding(0);
            this.a32.Name = "a32";
            this.a32.Size = new System.Drawing.Size(94, 71);
            this.a32.TabIndex = 1;
            this.a32.WrapContents = false;
            this.a32.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel34
            // 
            this.tableLayoutPanel34.ColumnCount = 1;
            this.tableLayoutPanel34.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel34.Controls.Add(this.ad31, 0, 0);
            this.tableLayoutPanel34.Controls.Add(this.a31, 0, 1);
            this.tableLayoutPanel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel34.Location = new System.Drawing.Point(188, 396);
            this.tableLayoutPanel34.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel34.Name = "tableLayoutPanel34";
            this.tableLayoutPanel34.RowCount = 2;
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel34.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel34.Size = new System.Drawing.Size(94, 88);
            this.tableLayoutPanel34.TabIndex = 131;
            // 
            // ad31
            // 
            this.ad31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad31.Location = new System.Drawing.Point(0, 0);
            this.ad31.Margin = new System.Windows.Forms.Padding(0);
            this.ad31.Name = "ad31";
            this.ad31.Size = new System.Drawing.Size(94, 17);
            this.ad31.TabIndex = 0;
            this.ad31.Click += new System.EventHandler(this.a30_Click);
            // 
            // a31
            // 
            this.a31.AutoScroll = true;
            this.a31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a31.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a31.Location = new System.Drawing.Point(0, 17);
            this.a31.Margin = new System.Windows.Forms.Padding(0);
            this.a31.Name = "a31";
            this.a31.Size = new System.Drawing.Size(94, 71);
            this.a31.TabIndex = 1;
            this.a31.WrapContents = false;
            this.a31.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel33
            // 
            this.tableLayoutPanel33.ColumnCount = 1;
            this.tableLayoutPanel33.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel33.Controls.Add(this.ad30, 0, 0);
            this.tableLayoutPanel33.Controls.Add(this.a30, 0, 1);
            this.tableLayoutPanel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel33.Location = new System.Drawing.Point(94, 396);
            this.tableLayoutPanel33.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel33.Name = "tableLayoutPanel33";
            this.tableLayoutPanel33.RowCount = 2;
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel33.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel33.Size = new System.Drawing.Size(94, 88);
            this.tableLayoutPanel33.TabIndex = 130;
            // 
            // ad30
            // 
            this.ad30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad30.Location = new System.Drawing.Point(0, 0);
            this.ad30.Margin = new System.Windows.Forms.Padding(0);
            this.ad30.Name = "ad30";
            this.ad30.Size = new System.Drawing.Size(94, 17);
            this.ad30.TabIndex = 0;
            this.ad30.Click += new System.EventHandler(this.a30_Click);
            // 
            // a30
            // 
            this.a30.AutoScroll = true;
            this.a30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a30.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a30.Location = new System.Drawing.Point(0, 17);
            this.a30.Margin = new System.Windows.Forms.Padding(0);
            this.a30.Name = "a30";
            this.a30.Size = new System.Drawing.Size(94, 71);
            this.a30.TabIndex = 1;
            this.a30.WrapContents = false;
            this.a30.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel32
            // 
            this.tableLayoutPanel32.ColumnCount = 1;
            this.tableLayoutPanel32.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel32.Controls.Add(this.ad29, 0, 0);
            this.tableLayoutPanel32.Controls.Add(this.a29, 0, 1);
            this.tableLayoutPanel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel32.Location = new System.Drawing.Point(0, 396);
            this.tableLayoutPanel32.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel32.Name = "tableLayoutPanel32";
            this.tableLayoutPanel32.RowCount = 2;
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel32.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel32.Size = new System.Drawing.Size(94, 88);
            this.tableLayoutPanel32.TabIndex = 129;
            this.tableLayoutPanel32.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel32_Paint);
            // 
            // ad29
            // 
            this.ad29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad29.Location = new System.Drawing.Point(0, 0);
            this.ad29.Margin = new System.Windows.Forms.Padding(0);
            this.ad29.Name = "ad29";
            this.ad29.Size = new System.Drawing.Size(94, 17);
            this.ad29.TabIndex = 0;
            this.ad29.Click += new System.EventHandler(this.a30_Click);
            // 
            // a29
            // 
            this.a29.AutoScroll = true;
            this.a29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a29.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a29.Location = new System.Drawing.Point(0, 17);
            this.a29.Margin = new System.Windows.Forms.Padding(0);
            this.a29.Name = "a29";
            this.a29.Size = new System.Drawing.Size(94, 71);
            this.a29.TabIndex = 1;
            this.a29.WrapContents = false;
            this.a29.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel31
            // 
            this.tableLayoutPanel31.ColumnCount = 1;
            this.tableLayoutPanel31.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel31.Controls.Add(this.ad28, 0, 0);
            this.tableLayoutPanel31.Controls.Add(this.a28, 0, 1);
            this.tableLayoutPanel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel31.Location = new System.Drawing.Point(564, 309);
            this.tableLayoutPanel31.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel31.Name = "tableLayoutPanel31";
            this.tableLayoutPanel31.RowCount = 2;
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel31.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel31.Size = new System.Drawing.Size(101, 87);
            this.tableLayoutPanel31.TabIndex = 128;
            // 
            // ad28
            // 
            this.ad28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad28.Location = new System.Drawing.Point(0, 0);
            this.ad28.Margin = new System.Windows.Forms.Padding(0);
            this.ad28.Name = "ad28";
            this.ad28.Size = new System.Drawing.Size(101, 17);
            this.ad28.TabIndex = 0;
            this.ad28.Click += new System.EventHandler(this.a30_Click);
            // 
            // a28
            // 
            this.a28.AutoScroll = true;
            this.a28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a28.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a28.Location = new System.Drawing.Point(0, 17);
            this.a28.Margin = new System.Windows.Forms.Padding(0);
            this.a28.Name = "a28";
            this.a28.Size = new System.Drawing.Size(101, 70);
            this.a28.TabIndex = 1;
            this.a28.WrapContents = false;
            this.a28.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel30
            // 
            this.tableLayoutPanel30.ColumnCount = 1;
            this.tableLayoutPanel30.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel30.Controls.Add(this.ad27, 0, 0);
            this.tableLayoutPanel30.Controls.Add(this.a27, 0, 1);
            this.tableLayoutPanel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel30.Location = new System.Drawing.Point(470, 309);
            this.tableLayoutPanel30.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel30.Name = "tableLayoutPanel30";
            this.tableLayoutPanel30.RowCount = 2;
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel30.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel30.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel30.TabIndex = 127;
            this.tableLayoutPanel30.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel30_Paint);
            // 
            // ad27
            // 
            this.ad27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad27.Location = new System.Drawing.Point(0, 0);
            this.ad27.Margin = new System.Windows.Forms.Padding(0);
            this.ad27.Name = "ad27";
            this.ad27.Size = new System.Drawing.Size(94, 17);
            this.ad27.TabIndex = 0;
            this.ad27.Click += new System.EventHandler(this.a30_Click);
            // 
            // a27
            // 
            this.a27.AutoScroll = true;
            this.a27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a27.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a27.Location = new System.Drawing.Point(0, 17);
            this.a27.Margin = new System.Windows.Forms.Padding(0);
            this.a27.Name = "a27";
            this.a27.Size = new System.Drawing.Size(94, 70);
            this.a27.TabIndex = 1;
            this.a27.WrapContents = false;
            this.a27.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel29
            // 
            this.tableLayoutPanel29.ColumnCount = 1;
            this.tableLayoutPanel29.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel29.Controls.Add(this.ad26, 0, 0);
            this.tableLayoutPanel29.Controls.Add(this.a26, 0, 1);
            this.tableLayoutPanel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel29.Location = new System.Drawing.Point(376, 309);
            this.tableLayoutPanel29.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel29.Name = "tableLayoutPanel29";
            this.tableLayoutPanel29.RowCount = 2;
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel29.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel29.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel29.TabIndex = 126;
            // 
            // ad26
            // 
            this.ad26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad26.Location = new System.Drawing.Point(0, 0);
            this.ad26.Margin = new System.Windows.Forms.Padding(0);
            this.ad26.Name = "ad26";
            this.ad26.Size = new System.Drawing.Size(94, 17);
            this.ad26.TabIndex = 0;
            this.ad26.Click += new System.EventHandler(this.a30_Click);
            // 
            // a26
            // 
            this.a26.AutoScroll = true;
            this.a26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a26.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a26.Location = new System.Drawing.Point(0, 17);
            this.a26.Margin = new System.Windows.Forms.Padding(0);
            this.a26.Name = "a26";
            this.a26.Size = new System.Drawing.Size(94, 70);
            this.a26.TabIndex = 1;
            this.a26.WrapContents = false;
            this.a26.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel28
            // 
            this.tableLayoutPanel28.ColumnCount = 1;
            this.tableLayoutPanel28.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel28.Controls.Add(this.ad25, 0, 0);
            this.tableLayoutPanel28.Controls.Add(this.a25, 0, 1);
            this.tableLayoutPanel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel28.Location = new System.Drawing.Point(282, 309);
            this.tableLayoutPanel28.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel28.Name = "tableLayoutPanel28";
            this.tableLayoutPanel28.RowCount = 2;
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel28.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel28.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel28.TabIndex = 125;
            // 
            // ad25
            // 
            this.ad25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad25.Location = new System.Drawing.Point(0, 0);
            this.ad25.Margin = new System.Windows.Forms.Padding(0);
            this.ad25.Name = "ad25";
            this.ad25.Size = new System.Drawing.Size(94, 17);
            this.ad25.TabIndex = 0;
            this.ad25.Click += new System.EventHandler(this.a30_Click);
            // 
            // a25
            // 
            this.a25.AutoScroll = true;
            this.a25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a25.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a25.Location = new System.Drawing.Point(0, 17);
            this.a25.Margin = new System.Windows.Forms.Padding(0);
            this.a25.Name = "a25";
            this.a25.Size = new System.Drawing.Size(94, 70);
            this.a25.TabIndex = 1;
            this.a25.WrapContents = false;
            this.a25.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel27
            // 
            this.tableLayoutPanel27.ColumnCount = 1;
            this.tableLayoutPanel27.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel27.Controls.Add(this.ad24, 0, 0);
            this.tableLayoutPanel27.Controls.Add(this.a24, 0, 1);
            this.tableLayoutPanel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel27.Location = new System.Drawing.Point(188, 309);
            this.tableLayoutPanel27.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel27.Name = "tableLayoutPanel27";
            this.tableLayoutPanel27.RowCount = 2;
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel27.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel27.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel27.TabIndex = 124;
            // 
            // ad24
            // 
            this.ad24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad24.Location = new System.Drawing.Point(0, 0);
            this.ad24.Margin = new System.Windows.Forms.Padding(0);
            this.ad24.Name = "ad24";
            this.ad24.Size = new System.Drawing.Size(94, 17);
            this.ad24.TabIndex = 0;
            this.ad24.Click += new System.EventHandler(this.a30_Click);
            // 
            // a24
            // 
            this.a24.AutoScroll = true;
            this.a24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a24.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a24.Location = new System.Drawing.Point(0, 17);
            this.a24.Margin = new System.Windows.Forms.Padding(0);
            this.a24.Name = "a24";
            this.a24.Size = new System.Drawing.Size(94, 70);
            this.a24.TabIndex = 1;
            this.a24.WrapContents = false;
            this.a24.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel26
            // 
            this.tableLayoutPanel26.ColumnCount = 1;
            this.tableLayoutPanel26.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel26.Controls.Add(this.ad23, 0, 0);
            this.tableLayoutPanel26.Controls.Add(this.a23, 0, 1);
            this.tableLayoutPanel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel26.Location = new System.Drawing.Point(94, 309);
            this.tableLayoutPanel26.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel26.Name = "tableLayoutPanel26";
            this.tableLayoutPanel26.RowCount = 2;
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel26.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel26.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel26.TabIndex = 123;
            // 
            // ad23
            // 
            this.ad23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad23.Location = new System.Drawing.Point(0, 0);
            this.ad23.Margin = new System.Windows.Forms.Padding(0);
            this.ad23.Name = "ad23";
            this.ad23.Size = new System.Drawing.Size(94, 17);
            this.ad23.TabIndex = 0;
            this.ad23.Click += new System.EventHandler(this.a30_Click);
            // 
            // a23
            // 
            this.a23.AutoScroll = true;
            this.a23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a23.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a23.Location = new System.Drawing.Point(0, 17);
            this.a23.Margin = new System.Windows.Forms.Padding(0);
            this.a23.Name = "a23";
            this.a23.Size = new System.Drawing.Size(94, 70);
            this.a23.TabIndex = 1;
            this.a23.WrapContents = false;
            this.a23.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel25
            // 
            this.tableLayoutPanel25.ColumnCount = 1;
            this.tableLayoutPanel25.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel25.Controls.Add(this.ad22, 0, 0);
            this.tableLayoutPanel25.Controls.Add(this.a22, 0, 1);
            this.tableLayoutPanel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel25.Location = new System.Drawing.Point(0, 309);
            this.tableLayoutPanel25.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel25.Name = "tableLayoutPanel25";
            this.tableLayoutPanel25.RowCount = 2;
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel25.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel25.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel25.TabIndex = 122;
            // 
            // ad22
            // 
            this.ad22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad22.Location = new System.Drawing.Point(0, 0);
            this.ad22.Margin = new System.Windows.Forms.Padding(0);
            this.ad22.Name = "ad22";
            this.ad22.Size = new System.Drawing.Size(94, 17);
            this.ad22.TabIndex = 0;
            this.ad22.Click += new System.EventHandler(this.a30_Click);
            // 
            // a22
            // 
            this.a22.AutoScroll = true;
            this.a22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a22.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a22.Location = new System.Drawing.Point(0, 17);
            this.a22.Margin = new System.Windows.Forms.Padding(0);
            this.a22.Name = "a22";
            this.a22.Size = new System.Drawing.Size(94, 70);
            this.a22.TabIndex = 1;
            this.a22.WrapContents = false;
            this.a22.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel24
            // 
            this.tableLayoutPanel24.ColumnCount = 1;
            this.tableLayoutPanel24.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel24.Controls.Add(this.ad21, 0, 0);
            this.tableLayoutPanel24.Controls.Add(this.a21, 0, 1);
            this.tableLayoutPanel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel24.Location = new System.Drawing.Point(564, 222);
            this.tableLayoutPanel24.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel24.Name = "tableLayoutPanel24";
            this.tableLayoutPanel24.RowCount = 2;
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel24.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel24.Size = new System.Drawing.Size(101, 87);
            this.tableLayoutPanel24.TabIndex = 121;
            // 
            // ad21
            // 
            this.ad21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad21.Location = new System.Drawing.Point(0, 0);
            this.ad21.Margin = new System.Windows.Forms.Padding(0);
            this.ad21.Name = "ad21";
            this.ad21.Size = new System.Drawing.Size(101, 17);
            this.ad21.TabIndex = 0;
            this.ad21.Click += new System.EventHandler(this.a30_Click);
            // 
            // a21
            // 
            this.a21.AutoScroll = true;
            this.a21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a21.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a21.Location = new System.Drawing.Point(0, 17);
            this.a21.Margin = new System.Windows.Forms.Padding(0);
            this.a21.Name = "a21";
            this.a21.Size = new System.Drawing.Size(101, 70);
            this.a21.TabIndex = 1;
            this.a21.WrapContents = false;
            this.a21.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel23
            // 
            this.tableLayoutPanel23.ColumnCount = 1;
            this.tableLayoutPanel23.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel23.Controls.Add(this.ad20, 0, 0);
            this.tableLayoutPanel23.Controls.Add(this.a20, 0, 1);
            this.tableLayoutPanel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel23.Location = new System.Drawing.Point(470, 222);
            this.tableLayoutPanel23.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel23.Name = "tableLayoutPanel23";
            this.tableLayoutPanel23.RowCount = 2;
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel23.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel23.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel23.TabIndex = 120;
            // 
            // ad20
            // 
            this.ad20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad20.Location = new System.Drawing.Point(0, 0);
            this.ad20.Margin = new System.Windows.Forms.Padding(0);
            this.ad20.Name = "ad20";
            this.ad20.Size = new System.Drawing.Size(94, 17);
            this.ad20.TabIndex = 0;
            this.ad20.Click += new System.EventHandler(this.a30_Click);
            // 
            // a20
            // 
            this.a20.AutoScroll = true;
            this.a20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a20.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a20.Location = new System.Drawing.Point(0, 17);
            this.a20.Margin = new System.Windows.Forms.Padding(0);
            this.a20.Name = "a20";
            this.a20.Size = new System.Drawing.Size(94, 70);
            this.a20.TabIndex = 1;
            this.a20.WrapContents = false;
            this.a20.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel22
            // 
            this.tableLayoutPanel22.ColumnCount = 1;
            this.tableLayoutPanel22.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel22.Controls.Add(this.ad19, 0, 0);
            this.tableLayoutPanel22.Controls.Add(this.a19, 0, 1);
            this.tableLayoutPanel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel22.Location = new System.Drawing.Point(376, 222);
            this.tableLayoutPanel22.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel22.Name = "tableLayoutPanel22";
            this.tableLayoutPanel22.RowCount = 2;
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel22.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel22.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel22.TabIndex = 119;
            // 
            // ad19
            // 
            this.ad19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad19.Location = new System.Drawing.Point(0, 0);
            this.ad19.Margin = new System.Windows.Forms.Padding(0);
            this.ad19.Name = "ad19";
            this.ad19.Size = new System.Drawing.Size(94, 17);
            this.ad19.TabIndex = 0;
            this.ad19.Click += new System.EventHandler(this.a30_Click);
            // 
            // a19
            // 
            this.a19.AutoScroll = true;
            this.a19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a19.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a19.Location = new System.Drawing.Point(0, 17);
            this.a19.Margin = new System.Windows.Forms.Padding(0);
            this.a19.Name = "a19";
            this.a19.Size = new System.Drawing.Size(94, 70);
            this.a19.TabIndex = 1;
            this.a19.WrapContents = false;
            this.a19.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel21
            // 
            this.tableLayoutPanel21.ColumnCount = 1;
            this.tableLayoutPanel21.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel21.Controls.Add(this.ad18, 0, 0);
            this.tableLayoutPanel21.Controls.Add(this.a18, 0, 1);
            this.tableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel21.Location = new System.Drawing.Point(282, 222);
            this.tableLayoutPanel21.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel21.Name = "tableLayoutPanel21";
            this.tableLayoutPanel21.RowCount = 2;
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel21.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel21.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel21.TabIndex = 118;
            // 
            // ad18
            // 
            this.ad18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad18.Location = new System.Drawing.Point(0, 0);
            this.ad18.Margin = new System.Windows.Forms.Padding(0);
            this.ad18.Name = "ad18";
            this.ad18.Size = new System.Drawing.Size(94, 17);
            this.ad18.TabIndex = 0;
            this.ad18.Click += new System.EventHandler(this.a30_Click);
            // 
            // a18
            // 
            this.a18.AutoScroll = true;
            this.a18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a18.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a18.Location = new System.Drawing.Point(0, 17);
            this.a18.Margin = new System.Windows.Forms.Padding(0);
            this.a18.Name = "a18";
            this.a18.Size = new System.Drawing.Size(94, 70);
            this.a18.TabIndex = 1;
            this.a18.WrapContents = false;
            this.a18.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel20
            // 
            this.tableLayoutPanel20.ColumnCount = 1;
            this.tableLayoutPanel20.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel20.Controls.Add(this.ad17, 0, 0);
            this.tableLayoutPanel20.Controls.Add(this.a17, 0, 1);
            this.tableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel20.Location = new System.Drawing.Point(188, 222);
            this.tableLayoutPanel20.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel20.Name = "tableLayoutPanel20";
            this.tableLayoutPanel20.RowCount = 2;
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel20.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel20.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel20.TabIndex = 117;
            // 
            // ad17
            // 
            this.ad17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad17.Location = new System.Drawing.Point(0, 0);
            this.ad17.Margin = new System.Windows.Forms.Padding(0);
            this.ad17.Name = "ad17";
            this.ad17.Size = new System.Drawing.Size(94, 17);
            this.ad17.TabIndex = 0;
            this.ad17.Click += new System.EventHandler(this.a30_Click);
            // 
            // a17
            // 
            this.a17.AutoScroll = true;
            this.a17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a17.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a17.Location = new System.Drawing.Point(0, 17);
            this.a17.Margin = new System.Windows.Forms.Padding(0);
            this.a17.Name = "a17";
            this.a17.Size = new System.Drawing.Size(94, 70);
            this.a17.TabIndex = 1;
            this.a17.WrapContents = false;
            this.a17.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel19
            // 
            this.tableLayoutPanel19.ColumnCount = 1;
            this.tableLayoutPanel19.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel19.Controls.Add(this.ad16, 0, 0);
            this.tableLayoutPanel19.Controls.Add(this.a16, 0, 1);
            this.tableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel19.Location = new System.Drawing.Point(94, 222);
            this.tableLayoutPanel19.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel19.Name = "tableLayoutPanel19";
            this.tableLayoutPanel19.RowCount = 2;
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel19.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel19.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel19.TabIndex = 116;
            // 
            // ad16
            // 
            this.ad16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad16.Location = new System.Drawing.Point(0, 0);
            this.ad16.Margin = new System.Windows.Forms.Padding(0);
            this.ad16.Name = "ad16";
            this.ad16.Size = new System.Drawing.Size(94, 17);
            this.ad16.TabIndex = 0;
            this.ad16.Click += new System.EventHandler(this.a30_Click);
            // 
            // a16
            // 
            this.a16.AutoScroll = true;
            this.a16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a16.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a16.Location = new System.Drawing.Point(0, 17);
            this.a16.Margin = new System.Windows.Forms.Padding(0);
            this.a16.Name = "a16";
            this.a16.Size = new System.Drawing.Size(94, 70);
            this.a16.TabIndex = 1;
            this.a16.WrapContents = false;
            this.a16.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel18
            // 
            this.tableLayoutPanel18.ColumnCount = 1;
            this.tableLayoutPanel18.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel18.Controls.Add(this.ad15, 0, 0);
            this.tableLayoutPanel18.Controls.Add(this.a15, 0, 1);
            this.tableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel18.Location = new System.Drawing.Point(0, 222);
            this.tableLayoutPanel18.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel18.Name = "tableLayoutPanel18";
            this.tableLayoutPanel18.RowCount = 2;
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel18.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel18.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel18.TabIndex = 115;
            // 
            // ad15
            // 
            this.ad15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad15.Location = new System.Drawing.Point(0, 0);
            this.ad15.Margin = new System.Windows.Forms.Padding(0);
            this.ad15.Name = "ad15";
            this.ad15.Size = new System.Drawing.Size(94, 17);
            this.ad15.TabIndex = 0;
            this.ad15.Click += new System.EventHandler(this.a30_Click);
            // 
            // a15
            // 
            this.a15.AutoScroll = true;
            this.a15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a15.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a15.Location = new System.Drawing.Point(0, 17);
            this.a15.Margin = new System.Windows.Forms.Padding(0);
            this.a15.Name = "a15";
            this.a15.Size = new System.Drawing.Size(94, 70);
            this.a15.TabIndex = 1;
            this.a15.WrapContents = false;
            this.a15.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel17
            // 
            this.tableLayoutPanel17.ColumnCount = 1;
            this.tableLayoutPanel17.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel17.Controls.Add(this.ad14, 0, 0);
            this.tableLayoutPanel17.Controls.Add(this.a14, 0, 1);
            this.tableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel17.Location = new System.Drawing.Point(564, 135);
            this.tableLayoutPanel17.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel17.Name = "tableLayoutPanel17";
            this.tableLayoutPanel17.RowCount = 2;
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel17.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel17.Size = new System.Drawing.Size(101, 87);
            this.tableLayoutPanel17.TabIndex = 114;
            // 
            // ad14
            // 
            this.ad14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad14.Location = new System.Drawing.Point(0, 0);
            this.ad14.Margin = new System.Windows.Forms.Padding(0);
            this.ad14.Name = "ad14";
            this.ad14.Size = new System.Drawing.Size(101, 17);
            this.ad14.TabIndex = 0;
            this.ad14.Click += new System.EventHandler(this.a30_Click);
            // 
            // a14
            // 
            this.a14.AutoScroll = true;
            this.a14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a14.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a14.Location = new System.Drawing.Point(0, 17);
            this.a14.Margin = new System.Windows.Forms.Padding(0);
            this.a14.Name = "a14";
            this.a14.Size = new System.Drawing.Size(101, 70);
            this.a14.TabIndex = 1;
            this.a14.WrapContents = false;
            this.a14.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel16
            // 
            this.tableLayoutPanel16.ColumnCount = 1;
            this.tableLayoutPanel16.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel16.Controls.Add(this.ad13, 0, 0);
            this.tableLayoutPanel16.Controls.Add(this.a13, 0, 1);
            this.tableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel16.Location = new System.Drawing.Point(470, 135);
            this.tableLayoutPanel16.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel16.Name = "tableLayoutPanel16";
            this.tableLayoutPanel16.RowCount = 2;
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel16.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel16.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel16.TabIndex = 113;
            // 
            // ad13
            // 
            this.ad13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad13.Location = new System.Drawing.Point(0, 0);
            this.ad13.Margin = new System.Windows.Forms.Padding(0);
            this.ad13.Name = "ad13";
            this.ad13.Size = new System.Drawing.Size(94, 17);
            this.ad13.TabIndex = 0;
            // 
            // a13
            // 
            this.a13.AutoScroll = true;
            this.a13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a13.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a13.Location = new System.Drawing.Point(0, 17);
            this.a13.Margin = new System.Windows.Forms.Padding(0);
            this.a13.Name = "a13";
            this.a13.Size = new System.Drawing.Size(94, 70);
            this.a13.TabIndex = 1;
            this.a13.WrapContents = false;
            this.a13.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 1;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel15.Controls.Add(this.ad12, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.a12, 0, 1);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(376, 135);
            this.tableLayoutPanel15.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel15.TabIndex = 112;
            // 
            // ad12
            // 
            this.ad12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad12.Location = new System.Drawing.Point(0, 0);
            this.ad12.Margin = new System.Windows.Forms.Padding(0);
            this.ad12.Name = "ad12";
            this.ad12.Size = new System.Drawing.Size(94, 17);
            this.ad12.TabIndex = 0;
            this.ad12.Click += new System.EventHandler(this.a30_Click);
            // 
            // a12
            // 
            this.a12.AutoScroll = true;
            this.a12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a12.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a12.Location = new System.Drawing.Point(0, 17);
            this.a12.Margin = new System.Windows.Forms.Padding(0);
            this.a12.Name = "a12";
            this.a12.Size = new System.Drawing.Size(94, 70);
            this.a12.TabIndex = 1;
            this.a12.WrapContents = false;
            this.a12.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 1;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel14.Controls.Add(this.ad11, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.a11, 0, 1);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(282, 135);
            this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel14.TabIndex = 111;
            // 
            // ad11
            // 
            this.ad11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad11.Location = new System.Drawing.Point(0, 0);
            this.ad11.Margin = new System.Windows.Forms.Padding(0);
            this.ad11.Name = "ad11";
            this.ad11.Size = new System.Drawing.Size(94, 17);
            this.ad11.TabIndex = 0;
            this.ad11.Click += new System.EventHandler(this.a30_Click);
            // 
            // a11
            // 
            this.a11.AutoScroll = true;
            this.a11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a11.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a11.Location = new System.Drawing.Point(0, 17);
            this.a11.Margin = new System.Windows.Forms.Padding(0);
            this.a11.Name = "a11";
            this.a11.Size = new System.Drawing.Size(94, 70);
            this.a11.TabIndex = 1;
            this.a11.WrapContents = false;
            this.a11.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Controls.Add(this.ad10, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.a10, 0, 1);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(188, 135);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel13.TabIndex = 110;
            // 
            // ad10
            // 
            this.ad10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad10.Location = new System.Drawing.Point(0, 0);
            this.ad10.Margin = new System.Windows.Forms.Padding(0);
            this.ad10.Name = "ad10";
            this.ad10.Size = new System.Drawing.Size(94, 17);
            this.ad10.TabIndex = 0;
            this.ad10.Click += new System.EventHandler(this.a30_Click);
            // 
            // a10
            // 
            this.a10.AutoScroll = true;
            this.a10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a10.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a10.Location = new System.Drawing.Point(0, 17);
            this.a10.Margin = new System.Windows.Forms.Padding(0);
            this.a10.Name = "a10";
            this.a10.Size = new System.Drawing.Size(94, 70);
            this.a10.TabIndex = 1;
            this.a10.WrapContents = false;
            this.a10.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel12.Controls.Add(this.ad9, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.a9, 0, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(94, 135);
            this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel12.TabIndex = 109;
            // 
            // ad9
            // 
            this.ad9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad9.Location = new System.Drawing.Point(0, 0);
            this.ad9.Margin = new System.Windows.Forms.Padding(0);
            this.ad9.Name = "ad9";
            this.ad9.Size = new System.Drawing.Size(94, 17);
            this.ad9.TabIndex = 0;
            this.ad9.Click += new System.EventHandler(this.a30_Click);
            // 
            // a9
            // 
            this.a9.AutoScroll = true;
            this.a9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a9.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a9.Location = new System.Drawing.Point(0, 17);
            this.a9.Margin = new System.Windows.Forms.Padding(0);
            this.a9.Name = "a9";
            this.a9.Size = new System.Drawing.Size(94, 70);
            this.a9.TabIndex = 1;
            this.a9.WrapContents = false;
            this.a9.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Controls.Add(this.ad8, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.a8, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 135);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel11.TabIndex = 108;
            // 
            // ad8
            // 
            this.ad8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad8.Location = new System.Drawing.Point(0, 0);
            this.ad8.Margin = new System.Windows.Forms.Padding(0);
            this.ad8.Name = "ad8";
            this.ad8.Size = new System.Drawing.Size(94, 17);
            this.ad8.TabIndex = 0;
            this.ad8.Click += new System.EventHandler(this.a30_Click);
            // 
            // a8
            // 
            this.a8.AutoScroll = true;
            this.a8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a8.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a8.Location = new System.Drawing.Point(0, 17);
            this.a8.Margin = new System.Windows.Forms.Padding(0);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(94, 70);
            this.a8.TabIndex = 1;
            this.a8.WrapContents = false;
            this.a8.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 1;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Controls.Add(this.ad7, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.a7, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(564, 48);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(101, 87);
            this.tableLayoutPanel10.TabIndex = 107;
            // 
            // ad7
            // 
            this.ad7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad7.Location = new System.Drawing.Point(0, 0);
            this.ad7.Margin = new System.Windows.Forms.Padding(0);
            this.ad7.Name = "ad7";
            this.ad7.Size = new System.Drawing.Size(101, 17);
            this.ad7.TabIndex = 0;
            this.ad7.Click += new System.EventHandler(this.a30_Click);
            // 
            // a7
            // 
            this.a7.AutoScroll = true;
            this.a7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a7.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a7.Location = new System.Drawing.Point(0, 17);
            this.a7.Margin = new System.Windows.Forms.Padding(0);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(101, 70);
            this.a7.TabIndex = 1;
            this.a7.WrapContents = false;
            this.a7.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Controls.Add(this.ad6, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.a6, 0, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(470, 48);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel9.TabIndex = 106;
            // 
            // ad6
            // 
            this.ad6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad6.Location = new System.Drawing.Point(0, 0);
            this.ad6.Margin = new System.Windows.Forms.Padding(0);
            this.ad6.Name = "ad6";
            this.ad6.Size = new System.Drawing.Size(94, 17);
            this.ad6.TabIndex = 0;
            this.ad6.Click += new System.EventHandler(this.a30_Click);
            // 
            // a6
            // 
            this.a6.AutoScroll = true;
            this.a6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a6.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a6.Location = new System.Drawing.Point(0, 17);
            this.a6.Margin = new System.Windows.Forms.Padding(0);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(94, 70);
            this.a6.TabIndex = 1;
            this.a6.WrapContents = false;
            this.a6.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.ad5, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.a5, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(376, 48);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel8.TabIndex = 105;
            // 
            // ad5
            // 
            this.ad5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad5.Location = new System.Drawing.Point(0, 0);
            this.ad5.Margin = new System.Windows.Forms.Padding(0);
            this.ad5.Name = "ad5";
            this.ad5.Size = new System.Drawing.Size(94, 17);
            this.ad5.TabIndex = 0;
            this.ad5.Click += new System.EventHandler(this.a30_Click);
            // 
            // a5
            // 
            this.a5.AutoScroll = true;
            this.a5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a5.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a5.Location = new System.Drawing.Point(0, 17);
            this.a5.Margin = new System.Windows.Forms.Padding(0);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(94, 70);
            this.a5.TabIndex = 1;
            this.a5.WrapContents = false;
            this.a5.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.ad4, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.a4, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(282, 48);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel7.TabIndex = 104;
            // 
            // ad4
            // 
            this.ad4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad4.Location = new System.Drawing.Point(0, 0);
            this.ad4.Margin = new System.Windows.Forms.Padding(0);
            this.ad4.Name = "ad4";
            this.ad4.Size = new System.Drawing.Size(94, 17);
            this.ad4.TabIndex = 0;
            this.ad4.Click += new System.EventHandler(this.a30_Click);
            // 
            // a4
            // 
            this.a4.AutoScroll = true;
            this.a4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a4.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a4.Location = new System.Drawing.Point(0, 17);
            this.a4.Margin = new System.Windows.Forms.Padding(0);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(94, 70);
            this.a4.TabIndex = 1;
            this.a4.WrapContents = false;
            this.a4.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.ad3, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.a3, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(188, 48);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel6.TabIndex = 103;
            // 
            // ad3
            // 
            this.ad3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad3.Location = new System.Drawing.Point(0, 0);
            this.ad3.Margin = new System.Windows.Forms.Padding(0);
            this.ad3.Name = "ad3";
            this.ad3.Size = new System.Drawing.Size(94, 17);
            this.ad3.TabIndex = 0;
            this.ad3.Click += new System.EventHandler(this.a30_Click);
            // 
            // a3
            // 
            this.a3.AutoScroll = true;
            this.a3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a3.Location = new System.Drawing.Point(0, 17);
            this.a3.Margin = new System.Windows.Forms.Padding(0);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(94, 70);
            this.a3.TabIndex = 1;
            this.a3.WrapContents = false;
            this.a3.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.ad2, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.a2, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(94, 48);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel5.TabIndex = 102;
            // 
            // ad2
            // 
            this.ad2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad2.Location = new System.Drawing.Point(0, 0);
            this.ad2.Margin = new System.Windows.Forms.Padding(0);
            this.ad2.Name = "ad2";
            this.ad2.Size = new System.Drawing.Size(94, 17);
            this.ad2.TabIndex = 0;
            this.ad2.Click += new System.EventHandler(this.a30_Click);
            // 
            // a2
            // 
            this.a2.AutoScroll = true;
            this.a2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a2.Location = new System.Drawing.Point(0, 17);
            this.a2.Margin = new System.Windows.Forms.Padding(0);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(94, 70);
            this.a2.TabIndex = 1;
            this.a2.WrapContents = false;
            this.a2.Click += new System.EventHandler(this.a30_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Courier New", 14F);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label7.Location = new System.Drawing.Point(567, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 48);
            this.label7.TabIndex = 100;
            this.label7.Tag = "";
            this.label7.Text = "Sábado";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Courier New", 14F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 48);
            this.label1.TabIndex = 94;
            this.label1.Text = "Domingo";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Courier New", 14F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label6.Location = new System.Drawing.Point(473, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 48);
            this.label6.TabIndex = 99;
            this.label6.Text = "Sexta";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Courier New", 14F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label2.Location = new System.Drawing.Point(97, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 48);
            this.label2.TabIndex = 95;
            this.label2.Text = "Segunda";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Courier New", 14F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label5.Location = new System.Drawing.Point(379, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 48);
            this.label5.TabIndex = 98;
            this.label5.Text = "Quinta";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Courier New", 14F);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label3.Location = new System.Drawing.Point(191, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 48);
            this.label3.TabIndex = 96;
            this.label3.Text = "Terça";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Courier New", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.label4.Location = new System.Drawing.Point(285, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 48);
            this.label4.TabIndex = 97;
            this.label4.Text = "Quarta";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.ad1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.a1, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 48);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(94, 87);
            this.tableLayoutPanel4.TabIndex = 101;
            this.tableLayoutPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel4_Paint);
            // 
            // ad1
            // 
            this.ad1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ad1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.ad1.Location = new System.Drawing.Point(0, 0);
            this.ad1.Margin = new System.Windows.Forms.Padding(0);
            this.ad1.Name = "ad1";
            this.ad1.Size = new System.Drawing.Size(94, 17);
            this.ad1.TabIndex = 0;
            this.ad1.Click += new System.EventHandler(this.a30_Click);
            // 
            // a1
            // 
            this.a1.AutoScroll = true;
            this.a1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.a1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.a1.Location = new System.Drawing.Point(0, 17);
            this.a1.Margin = new System.Windows.Forms.Padding(0);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(94, 70);
            this.a1.TabIndex = 1;
            this.a1.WrapContents = false;
            this.a1.Click += new System.EventHandler(this.a30_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Controls.Add(this.bunifuThinButton21, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.bunifuThinButton22, 4, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 504);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(665, 56);
            this.tableLayoutPanel3.TabIndex = 1;
            this.tableLayoutPanel3.Resize += new System.EventHandler(this.tableLayoutPanel3_Resize);
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 20;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton21.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Atualizar";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuThinButton21.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 20;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton21.Location = new System.Drawing.Point(404, 5);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(123, 46);
            this.bunifuThinButton21.TabIndex = 35;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton21.Click += new System.EventHandler(this.btnAtualizar_Click);
            // 
            // bunifuThinButton22
            // 
            this.bunifuThinButton22.ActiveBorderThickness = 1;
            this.bunifuThinButton22.ActiveCornerRadius = 20;
            this.bunifuThinButton22.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton22.ActiveForecolor = System.Drawing.Color.Transparent;
            this.bunifuThinButton22.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton22.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton22.BackgroundImage")));
            this.bunifuThinButton22.ButtonText = "Fechar";
            this.bunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuThinButton22.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton22.ForeColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton22.IdleBorderThickness = 1;
            this.bunifuThinButton22.IdleCornerRadius = 20;
            this.bunifuThinButton22.IdleFillColor = System.Drawing.Color.White;
            this.bunifuThinButton22.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton22.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.bunifuThinButton22.Location = new System.Drawing.Point(537, 5);
            this.bunifuThinButton22.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton22.Name = "bunifuThinButton22";
            this.bunifuThinButton22.Size = new System.Drawing.Size(123, 46);
            this.bunifuThinButton22.TabIndex = 36;
            this.bunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton22.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Calendario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Calendario";
            this.Size = new System.Drawing.Size(665, 560);
            this.Load += new System.EventHandler(this.Calendario_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel38.ResumeLayout(false);
            this.tableLayoutPanel37.ResumeLayout(false);
            this.tableLayoutPanel36.ResumeLayout(false);
            this.tableLayoutPanel35.ResumeLayout(false);
            this.tableLayoutPanel34.ResumeLayout(false);
            this.tableLayoutPanel33.ResumeLayout(false);
            this.tableLayoutPanel32.ResumeLayout(false);
            this.tableLayoutPanel31.ResumeLayout(false);
            this.tableLayoutPanel30.ResumeLayout(false);
            this.tableLayoutPanel29.ResumeLayout(false);
            this.tableLayoutPanel28.ResumeLayout(false);
            this.tableLayoutPanel27.ResumeLayout(false);
            this.tableLayoutPanel26.ResumeLayout(false);
            this.tableLayoutPanel25.ResumeLayout(false);
            this.tableLayoutPanel24.ResumeLayout(false);
            this.tableLayoutPanel23.ResumeLayout(false);
            this.tableLayoutPanel22.ResumeLayout(false);
            this.tableLayoutPanel21.ResumeLayout(false);
            this.tableLayoutPanel20.ResumeLayout(false);
            this.tableLayoutPanel19.ResumeLayout(false);
            this.tableLayoutPanel18.ResumeLayout(false);
            this.tableLayoutPanel17.ResumeLayout(false);
            this.tableLayoutPanel16.ResumeLayout(false);
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label ad1;
        private System.Windows.Forms.FlowLayoutPanel a1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel38;
        private System.Windows.Forms.Label ad35;
        private System.Windows.Forms.FlowLayoutPanel a35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel37;
        private System.Windows.Forms.Label ad34;
        private System.Windows.Forms.FlowLayoutPanel a34;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel36;
        private System.Windows.Forms.Label ad33;
        private System.Windows.Forms.FlowLayoutPanel a33;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel35;
        private System.Windows.Forms.Label ad32;
        private System.Windows.Forms.FlowLayoutPanel a32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel34;
        private System.Windows.Forms.Label ad31;
        private System.Windows.Forms.FlowLayoutPanel a31;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel33;
        private System.Windows.Forms.Label ad30;
        private System.Windows.Forms.FlowLayoutPanel a30;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel32;
        private System.Windows.Forms.Label ad29;
        private System.Windows.Forms.FlowLayoutPanel a29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel31;
        private System.Windows.Forms.Label ad28;
        private System.Windows.Forms.FlowLayoutPanel a28;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel30;
        private System.Windows.Forms.Label ad27;
        private System.Windows.Forms.FlowLayoutPanel a27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel29;
        private System.Windows.Forms.Label ad26;
        private System.Windows.Forms.FlowLayoutPanel a26;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel28;
        private System.Windows.Forms.Label ad25;
        private System.Windows.Forms.FlowLayoutPanel a25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel27;
        private System.Windows.Forms.Label ad24;
        private System.Windows.Forms.FlowLayoutPanel a24;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel26;
        private System.Windows.Forms.Label ad23;
        private System.Windows.Forms.FlowLayoutPanel a23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel25;
        private System.Windows.Forms.Label ad22;
        private System.Windows.Forms.FlowLayoutPanel a22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel24;
        private System.Windows.Forms.Label ad21;
        private System.Windows.Forms.FlowLayoutPanel a21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel23;
        private System.Windows.Forms.Label ad20;
        private System.Windows.Forms.FlowLayoutPanel a20;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel22;
        private System.Windows.Forms.Label ad19;
        private System.Windows.Forms.FlowLayoutPanel a19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel21;
        private System.Windows.Forms.Label ad18;
        private System.Windows.Forms.FlowLayoutPanel a18;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel20;
        private System.Windows.Forms.Label ad17;
        private System.Windows.Forms.FlowLayoutPanel a17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel19;
        private System.Windows.Forms.Label ad16;
        private System.Windows.Forms.FlowLayoutPanel a16;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel18;
        private System.Windows.Forms.Label ad15;
        private System.Windows.Forms.FlowLayoutPanel a15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel17;
        private System.Windows.Forms.Label ad14;
        private System.Windows.Forms.FlowLayoutPanel a14;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel16;
        private System.Windows.Forms.Label ad13;
        private System.Windows.Forms.FlowLayoutPanel a13;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label ad12;
        private System.Windows.Forms.FlowLayoutPanel a12;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Label ad11;
        private System.Windows.Forms.FlowLayoutPanel a11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label ad10;
        private System.Windows.Forms.FlowLayoutPanel a10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label ad9;
        private System.Windows.Forms.FlowLayoutPanel a9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label ad8;
        private System.Windows.Forms.FlowLayoutPanel a8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label ad7;
        private System.Windows.Forms.FlowLayoutPanel a7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label ad6;
        private System.Windows.Forms.FlowLayoutPanel a6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label ad5;
        private System.Windows.Forms.FlowLayoutPanel a5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label ad4;
        private System.Windows.Forms.FlowLayoutPanel a4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label ad3;
        private System.Windows.Forms.FlowLayoutPanel a3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label ad2;
        private System.Windows.Forms.FlowLayoutPanel a2;

    }
}
