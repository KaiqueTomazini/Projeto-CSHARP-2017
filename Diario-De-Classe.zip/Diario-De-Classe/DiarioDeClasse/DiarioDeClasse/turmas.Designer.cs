﻿namespace DiarioDeClasse
{
    partial class turmas
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Component Designer

        /// <summary> 
        /// Método necessário para o suporte do Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(turmas));
            this.panel3 = new System.Windows.Forms.Panel();
            this.rbMedio = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.rbFund2 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.rbFund1 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn52 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn51 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn53 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn55 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn54 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn11 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn12 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn13 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn14 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn15 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn22 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn23 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn24 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn25 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn35 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn34 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn33 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn31 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btn32 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn41 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn42 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn43 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn44 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn45 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rbMedio);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(442, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(223, 28);
            this.panel3.TabIndex = 0;
            // 
            // rbMedio
            // 
            this.rbMedio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rbMedio.AutoSize = true;
            this.rbMedio.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.rbMedio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.rbMedio.Location = new System.Drawing.Point(78, 4);
            this.rbMedio.Name = "rbMedio";
            this.rbMedio.Size = new System.Drawing.Size(66, 20);
            this.rbMedio.TabIndex = 93;
            this.rbMedio.TabStop = true;
            this.rbMedio.Text = "Médio";
            this.rbMedio.UseVisualStyleBackColor = true;
            this.rbMedio.CheckedChanged += new System.EventHandler(this.rbMedio_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.rbFund2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(221, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(221, 28);
            this.panel4.TabIndex = 1;
            // 
            // rbFund2
            // 
            this.rbFund2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rbFund2.AutoSize = true;
            this.rbFund2.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.rbFund2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.rbFund2.Location = new System.Drawing.Point(41, 4);
            this.rbFund2.Name = "rbFund2";
            this.rbFund2.Size = new System.Drawing.Size(138, 20);
            this.rbFund2.TabIndex = 92;
            this.rbFund2.TabStop = true;
            this.rbFund2.Text = "Fundamental II";
            this.rbFund2.UseVisualStyleBackColor = true;
            this.rbFund2.CheckedChanged += new System.EventHandler(this.rbMedio_CheckedChanged);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(665, 28);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.rbFund1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(221, 28);
            this.panel5.TabIndex = 2;
            // 
            // rbFund1
            // 
            this.rbFund1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rbFund1.AutoSize = true;
            this.rbFund1.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.rbFund1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.rbFund1.Location = new System.Drawing.Point(45, 4);
            this.rbFund1.Name = "rbFund1";
            this.rbFund1.Size = new System.Drawing.Size(130, 20);
            this.rbFund1.TabIndex = 91;
            this.rbFund1.TabStop = true;
            this.rbFund1.Text = "Fundamental I";
            this.rbFund1.UseVisualStyleBackColor = true;
            this.rbFund1.CheckedChanged += new System.EventHandler(this.rbMedio_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 84);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(665, 28);
            this.panel2.TabIndex = 3;
            // 
            // btn52
            // 
            this.btn52.ActiveBorderThickness = 1;
            this.btn52.ActiveCornerRadius = 20;
            this.btn52.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn52.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn52.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn52.BackColor = System.Drawing.SystemColors.Control;
            this.btn52.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn52.BackgroundImage")));
            this.btn52.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn52.ButtonText = "ThinButton";
            this.btn52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn52.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn52.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn52.IdleBorderThickness = 1;
            this.btn52.IdleCornerRadius = 20;
            this.btn52.IdleFillColor = System.Drawing.Color.White;
            this.btn52.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn52.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn52.Location = new System.Drawing.Point(138, 361);
            this.btn52.Margin = new System.Windows.Forms.Padding(5);
            this.btn52.Name = "btn52";
            this.btn52.Size = new System.Drawing.Size(123, 82);
            this.btn52.TabIndex = 117;
            this.btn52.Tag = "a";
            this.btn52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn52.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn51
            // 
            this.btn51.ActiveBorderThickness = 1;
            this.btn51.ActiveCornerRadius = 20;
            this.btn51.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn51.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn51.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn51.BackColor = System.Drawing.SystemColors.Control;
            this.btn51.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn51.BackgroundImage")));
            this.btn51.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn51.ButtonText = "ThinButton";
            this.btn51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn51.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn51.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn51.IdleBorderThickness = 1;
            this.btn51.IdleCornerRadius = 20;
            this.btn51.IdleFillColor = System.Drawing.Color.White;
            this.btn51.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn51.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn51.Location = new System.Drawing.Point(5, 361);
            this.btn51.Margin = new System.Windows.Forms.Padding(5);
            this.btn51.Name = "btn51";
            this.btn51.Size = new System.Drawing.Size(123, 82);
            this.btn51.TabIndex = 116;
            this.btn51.Tag = "a";
            this.btn51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn51.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn53
            // 
            this.btn53.ActiveBorderThickness = 1;
            this.btn53.ActiveCornerRadius = 20;
            this.btn53.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn53.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn53.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn53.BackColor = System.Drawing.SystemColors.Control;
            this.btn53.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn53.BackgroundImage")));
            this.btn53.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn53.ButtonText = "ThinButton";
            this.btn53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn53.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn53.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn53.IdleBorderThickness = 1;
            this.btn53.IdleCornerRadius = 20;
            this.btn53.IdleFillColor = System.Drawing.Color.White;
            this.btn53.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn53.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn53.Location = new System.Drawing.Point(271, 361);
            this.btn53.Margin = new System.Windows.Forms.Padding(5);
            this.btn53.Name = "btn53";
            this.btn53.Size = new System.Drawing.Size(123, 82);
            this.btn53.TabIndex = 115;
            this.btn53.Tag = "a";
            this.btn53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn53.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn55
            // 
            this.btn55.ActiveBorderThickness = 1;
            this.btn55.ActiveCornerRadius = 20;
            this.btn55.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn55.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn55.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn55.BackColor = System.Drawing.SystemColors.Control;
            this.btn55.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn55.BackgroundImage")));
            this.btn55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn55.ButtonText = "ThinButton";
            this.btn55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn55.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn55.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn55.IdleBorderThickness = 1;
            this.btn55.IdleCornerRadius = 20;
            this.btn55.IdleFillColor = System.Drawing.Color.White;
            this.btn55.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn55.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn55.Location = new System.Drawing.Point(537, 361);
            this.btn55.Margin = new System.Windows.Forms.Padding(5);
            this.btn55.Name = "btn55";
            this.btn55.Size = new System.Drawing.Size(123, 82);
            this.btn55.TabIndex = 114;
            this.btn55.Tag = "a";
            this.btn55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn55.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn54
            // 
            this.btn54.ActiveBorderThickness = 1;
            this.btn54.ActiveCornerRadius = 20;
            this.btn54.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn54.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn54.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn54.BackColor = System.Drawing.SystemColors.Control;
            this.btn54.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn54.BackgroundImage")));
            this.btn54.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn54.ButtonText = "ThinButton";
            this.btn54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn54.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn54.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn54.IdleBorderThickness = 1;
            this.btn54.IdleCornerRadius = 20;
            this.btn54.IdleFillColor = System.Drawing.Color.White;
            this.btn54.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn54.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn54.Location = new System.Drawing.Point(404, 361);
            this.btn54.Margin = new System.Windows.Forms.Padding(5);
            this.btn54.Name = "btn54";
            this.btn54.Size = new System.Drawing.Size(123, 82);
            this.btn54.TabIndex = 113;
            this.btn54.Tag = "a";
            this.btn54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn54.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn11
            // 
            this.btn11.ActiveBorderThickness = 1;
            this.btn11.ActiveCornerRadius = 20;
            this.btn11.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn11.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn11.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn11.BackColor = System.Drawing.SystemColors.Control;
            this.btn11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn11.BackgroundImage")));
            this.btn11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn11.ButtonText = "ThinButton";
            this.btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn11.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn11.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn11.IdleBorderThickness = 1;
            this.btn11.IdleCornerRadius = 20;
            this.btn11.IdleFillColor = System.Drawing.Color.White;
            this.btn11.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn11.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn11.Location = new System.Drawing.Point(5, 5);
            this.btn11.Margin = new System.Windows.Forms.Padding(5);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(123, 79);
            this.btn11.TabIndex = 90;
            this.btn11.Tag = "a";
            this.btn11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn11.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn12
            // 
            this.btn12.ActiveBorderThickness = 1;
            this.btn12.ActiveCornerRadius = 20;
            this.btn12.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn12.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn12.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn12.BackColor = System.Drawing.SystemColors.Control;
            this.btn12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn12.BackgroundImage")));
            this.btn12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn12.ButtonText = "ThinButton";
            this.btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn12.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn12.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn12.IdleBorderThickness = 1;
            this.btn12.IdleCornerRadius = 20;
            this.btn12.IdleFillColor = System.Drawing.Color.White;
            this.btn12.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn12.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn12.Location = new System.Drawing.Point(138, 5);
            this.btn12.Margin = new System.Windows.Forms.Padding(5);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(123, 79);
            this.btn12.TabIndex = 91;
            this.btn12.Tag = "a";
            this.btn12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn12.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn13
            // 
            this.btn13.ActiveBorderThickness = 1;
            this.btn13.ActiveCornerRadius = 20;
            this.btn13.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn13.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn13.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn13.BackColor = System.Drawing.SystemColors.Control;
            this.btn13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn13.BackgroundImage")));
            this.btn13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn13.ButtonText = "ThinButton";
            this.btn13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn13.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn13.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn13.IdleBorderThickness = 1;
            this.btn13.IdleCornerRadius = 20;
            this.btn13.IdleFillColor = System.Drawing.Color.White;
            this.btn13.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn13.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn13.Location = new System.Drawing.Point(271, 5);
            this.btn13.Margin = new System.Windows.Forms.Padding(5);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(123, 79);
            this.btn13.TabIndex = 95;
            this.btn13.Tag = "a";
            this.btn13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn13.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn14
            // 
            this.btn14.ActiveBorderThickness = 1;
            this.btn14.ActiveCornerRadius = 20;
            this.btn14.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn14.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn14.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn14.BackColor = System.Drawing.SystemColors.Control;
            this.btn14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn14.BackgroundImage")));
            this.btn14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn14.ButtonText = "ThinButton";
            this.btn14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn14.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn14.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn14.IdleBorderThickness = 1;
            this.btn14.IdleCornerRadius = 20;
            this.btn14.IdleFillColor = System.Drawing.Color.White;
            this.btn14.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn14.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn14.Location = new System.Drawing.Point(404, 5);
            this.btn14.Margin = new System.Windows.Forms.Padding(5);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(123, 79);
            this.btn14.TabIndex = 94;
            this.btn14.Tag = "a";
            this.btn14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn14.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn15
            // 
            this.btn15.ActiveBorderThickness = 1;
            this.btn15.ActiveCornerRadius = 20;
            this.btn15.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn15.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn15.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn15.BackColor = System.Drawing.SystemColors.Control;
            this.btn15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn15.BackgroundImage")));
            this.btn15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn15.ButtonText = "ThinButton";
            this.btn15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn15.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn15.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn15.IdleBorderThickness = 1;
            this.btn15.IdleCornerRadius = 20;
            this.btn15.IdleFillColor = System.Drawing.Color.White;
            this.btn15.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn15.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn15.Location = new System.Drawing.Point(537, 5);
            this.btn15.Margin = new System.Windows.Forms.Padding(5);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(123, 79);
            this.btn15.TabIndex = 93;
            this.btn15.Tag = "a";
            this.btn15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn15.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn21
            // 
            this.btn21.ActiveBorderThickness = 1;
            this.btn21.ActiveCornerRadius = 20;
            this.btn21.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn21.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn21.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn21.BackColor = System.Drawing.SystemColors.Control;
            this.btn21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn21.BackgroundImage")));
            this.btn21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn21.ButtonText = "ThinButton";
            this.btn21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn21.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn21.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn21.IdleBorderThickness = 1;
            this.btn21.IdleCornerRadius = 20;
            this.btn21.IdleFillColor = System.Drawing.Color.White;
            this.btn21.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn21.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn21.Location = new System.Drawing.Point(5, 94);
            this.btn21.Margin = new System.Windows.Forms.Padding(5);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(123, 79);
            this.btn21.TabIndex = 92;
            this.btn21.Tag = "a";
            this.btn21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn21.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn22
            // 
            this.btn22.ActiveBorderThickness = 1;
            this.btn22.ActiveCornerRadius = 20;
            this.btn22.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn22.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn22.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn22.BackColor = System.Drawing.SystemColors.Control;
            this.btn22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn22.BackgroundImage")));
            this.btn22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn22.ButtonText = "ThinButton";
            this.btn22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn22.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn22.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn22.IdleBorderThickness = 1;
            this.btn22.IdleCornerRadius = 20;
            this.btn22.IdleFillColor = System.Drawing.Color.White;
            this.btn22.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn22.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn22.Location = new System.Drawing.Point(138, 94);
            this.btn22.Margin = new System.Windows.Forms.Padding(5);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(123, 79);
            this.btn22.TabIndex = 96;
            this.btn22.Tag = "a";
            this.btn22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn22.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn23
            // 
            this.btn23.ActiveBorderThickness = 1;
            this.btn23.ActiveCornerRadius = 20;
            this.btn23.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn23.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn23.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn23.BackColor = System.Drawing.SystemColors.Control;
            this.btn23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn23.BackgroundImage")));
            this.btn23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn23.ButtonText = "ThinButton";
            this.btn23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn23.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn23.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn23.IdleBorderThickness = 1;
            this.btn23.IdleCornerRadius = 20;
            this.btn23.IdleFillColor = System.Drawing.Color.White;
            this.btn23.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn23.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn23.Location = new System.Drawing.Point(271, 94);
            this.btn23.Margin = new System.Windows.Forms.Padding(5);
            this.btn23.Name = "btn23";
            this.btn23.Size = new System.Drawing.Size(123, 79);
            this.btn23.TabIndex = 97;
            this.btn23.Tag = "a";
            this.btn23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn23.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn24
            // 
            this.btn24.ActiveBorderThickness = 1;
            this.btn24.ActiveCornerRadius = 20;
            this.btn24.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn24.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn24.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn24.BackColor = System.Drawing.SystemColors.Control;
            this.btn24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn24.BackgroundImage")));
            this.btn24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn24.ButtonText = "ThinButton";
            this.btn24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn24.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn24.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn24.IdleBorderThickness = 1;
            this.btn24.IdleCornerRadius = 20;
            this.btn24.IdleFillColor = System.Drawing.Color.White;
            this.btn24.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn24.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn24.Location = new System.Drawing.Point(404, 94);
            this.btn24.Margin = new System.Windows.Forms.Padding(5);
            this.btn24.Name = "btn24";
            this.btn24.Size = new System.Drawing.Size(123, 79);
            this.btn24.TabIndex = 103;
            this.btn24.Tag = "a";
            this.btn24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn24.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn25
            // 
            this.btn25.ActiveBorderThickness = 1;
            this.btn25.ActiveCornerRadius = 20;
            this.btn25.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn25.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn25.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn25.BackColor = System.Drawing.SystemColors.Control;
            this.btn25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn25.BackgroundImage")));
            this.btn25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn25.ButtonText = "ThinButton";
            this.btn25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn25.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn25.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn25.IdleBorderThickness = 1;
            this.btn25.IdleCornerRadius = 20;
            this.btn25.IdleFillColor = System.Drawing.Color.White;
            this.btn25.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn25.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn25.Location = new System.Drawing.Point(537, 94);
            this.btn25.Margin = new System.Windows.Forms.Padding(5);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(123, 79);
            this.btn25.TabIndex = 98;
            this.btn25.Tag = "a";
            this.btn25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn25.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn35
            // 
            this.btn35.ActiveBorderThickness = 1;
            this.btn35.ActiveCornerRadius = 20;
            this.btn35.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn35.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn35.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn35.BackColor = System.Drawing.SystemColors.Control;
            this.btn35.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn35.BackgroundImage")));
            this.btn35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn35.ButtonText = "ThinButton";
            this.btn35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn35.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn35.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn35.IdleBorderThickness = 1;
            this.btn35.IdleCornerRadius = 20;
            this.btn35.IdleFillColor = System.Drawing.Color.White;
            this.btn35.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn35.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn35.Location = new System.Drawing.Point(537, 183);
            this.btn35.Margin = new System.Windows.Forms.Padding(5);
            this.btn35.Name = "btn35";
            this.btn35.Size = new System.Drawing.Size(123, 79);
            this.btn35.TabIndex = 100;
            this.btn35.Tag = "a";
            this.btn35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn35.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn34
            // 
            this.btn34.ActiveBorderThickness = 1;
            this.btn34.ActiveCornerRadius = 20;
            this.btn34.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn34.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn34.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn34.BackColor = System.Drawing.SystemColors.Control;
            this.btn34.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn34.BackgroundImage")));
            this.btn34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn34.ButtonText = "ThinButton";
            this.btn34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn34.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn34.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn34.IdleBorderThickness = 1;
            this.btn34.IdleCornerRadius = 20;
            this.btn34.IdleFillColor = System.Drawing.Color.White;
            this.btn34.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn34.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn34.Location = new System.Drawing.Point(404, 183);
            this.btn34.Margin = new System.Windows.Forms.Padding(5);
            this.btn34.Name = "btn34";
            this.btn34.Size = new System.Drawing.Size(123, 79);
            this.btn34.TabIndex = 99;
            this.btn34.Tag = "a";
            this.btn34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn34.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn33
            // 
            this.btn33.ActiveBorderThickness = 1;
            this.btn33.ActiveCornerRadius = 20;
            this.btn33.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn33.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn33.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn33.BackColor = System.Drawing.SystemColors.Control;
            this.btn33.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn33.BackgroundImage")));
            this.btn33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn33.ButtonText = "ThinButton";
            this.btn33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn33.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn33.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn33.IdleBorderThickness = 1;
            this.btn33.IdleCornerRadius = 20;
            this.btn33.IdleFillColor = System.Drawing.Color.White;
            this.btn33.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn33.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn33.Location = new System.Drawing.Point(271, 183);
            this.btn33.Margin = new System.Windows.Forms.Padding(5);
            this.btn33.Name = "btn33";
            this.btn33.Size = new System.Drawing.Size(123, 79);
            this.btn33.TabIndex = 101;
            this.btn33.Tag = "a";
            this.btn33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn33.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn31
            // 
            this.btn31.ActiveBorderThickness = 1;
            this.btn31.ActiveCornerRadius = 20;
            this.btn31.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn31.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn31.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn31.BackColor = System.Drawing.SystemColors.Control;
            this.btn31.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn31.BackgroundImage")));
            this.btn31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn31.ButtonText = "ThinButton";
            this.btn31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn31.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn31.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn31.IdleBorderThickness = 1;
            this.btn31.IdleCornerRadius = 20;
            this.btn31.IdleFillColor = System.Drawing.Color.White;
            this.btn31.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn31.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn31.Location = new System.Drawing.Point(5, 183);
            this.btn31.Margin = new System.Windows.Forms.Padding(5);
            this.btn31.Name = "btn31";
            this.btn31.Size = new System.Drawing.Size(123, 79);
            this.btn31.TabIndex = 102;
            this.btn31.Tag = "a";
            this.btn31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn31.Click += new System.EventHandler(this.btn_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(665, 560);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(665, 84);
            this.panel1.TabIndex = 0;
            this.panel1.Resize += new System.EventHandler(this.panel1_Resize);
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Courier New", 30F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(55)))), ((int)(((byte)(48)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(665, 84);
            this.label1.TabIndex = 91;
            this.label1.Tag = "";
            this.label1.Text = "Lista de turmas do colégio";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.btn_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Controls.Add(this.btn52, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.btn51, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.btn53, 2, 4);
            this.tableLayoutPanel3.Controls.Add(this.btn55, 4, 4);
            this.tableLayoutPanel3.Controls.Add(this.btn54, 3, 4);
            this.tableLayoutPanel3.Controls.Add(this.btn11, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn12, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn13, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn14, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn15, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn21, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn22, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn23, 2, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn24, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn25, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn35, 4, 2);
            this.tableLayoutPanel3.Controls.Add(this.btn34, 3, 2);
            this.tableLayoutPanel3.Controls.Add(this.btn33, 2, 2);
            this.tableLayoutPanel3.Controls.Add(this.btn31, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.btn32, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.btn41, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.btn42, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.btn43, 2, 3);
            this.tableLayoutPanel3.Controls.Add(this.btn44, 3, 3);
            this.tableLayoutPanel3.Controls.Add(this.btn45, 4, 3);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 112);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(665, 448);
            this.tableLayoutPanel3.TabIndex = 2;
            this.tableLayoutPanel3.Resize += new System.EventHandler(this.tableLayoutPanel3_Resize);
            // 
            // btn32
            // 
            this.btn32.ActiveBorderThickness = 1;
            this.btn32.ActiveCornerRadius = 20;
            this.btn32.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn32.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn32.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn32.BackColor = System.Drawing.SystemColors.Control;
            this.btn32.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn32.BackgroundImage")));
            this.btn32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn32.ButtonText = "ThinButton";
            this.btn32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn32.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn32.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn32.IdleBorderThickness = 1;
            this.btn32.IdleCornerRadius = 20;
            this.btn32.IdleFillColor = System.Drawing.Color.White;
            this.btn32.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn32.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn32.Location = new System.Drawing.Point(138, 183);
            this.btn32.Margin = new System.Windows.Forms.Padding(5);
            this.btn32.Name = "btn32";
            this.btn32.Size = new System.Drawing.Size(123, 79);
            this.btn32.TabIndex = 108;
            this.btn32.Tag = "a";
            this.btn32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn32.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn41
            // 
            this.btn41.ActiveBorderThickness = 1;
            this.btn41.ActiveCornerRadius = 20;
            this.btn41.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn41.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn41.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn41.BackColor = System.Drawing.SystemColors.Control;
            this.btn41.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn41.BackgroundImage")));
            this.btn41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn41.ButtonText = "ThinButton";
            this.btn41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn41.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn41.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn41.IdleBorderThickness = 1;
            this.btn41.IdleCornerRadius = 20;
            this.btn41.IdleFillColor = System.Drawing.Color.White;
            this.btn41.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn41.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn41.Location = new System.Drawing.Point(5, 272);
            this.btn41.Margin = new System.Windows.Forms.Padding(5);
            this.btn41.Name = "btn41";
            this.btn41.Size = new System.Drawing.Size(123, 79);
            this.btn41.TabIndex = 107;
            this.btn41.Tag = "a";
            this.btn41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn41.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn42
            // 
            this.btn42.ActiveBorderThickness = 1;
            this.btn42.ActiveCornerRadius = 20;
            this.btn42.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn42.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn42.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn42.BackColor = System.Drawing.SystemColors.Control;
            this.btn42.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn42.BackgroundImage")));
            this.btn42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn42.ButtonText = "ThinButton";
            this.btn42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn42.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn42.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn42.IdleBorderThickness = 1;
            this.btn42.IdleCornerRadius = 20;
            this.btn42.IdleFillColor = System.Drawing.Color.White;
            this.btn42.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn42.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn42.Location = new System.Drawing.Point(138, 272);
            this.btn42.Margin = new System.Windows.Forms.Padding(5);
            this.btn42.Name = "btn42";
            this.btn42.Size = new System.Drawing.Size(123, 79);
            this.btn42.TabIndex = 106;
            this.btn42.Tag = "a";
            this.btn42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn42.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn43
            // 
            this.btn43.ActiveBorderThickness = 1;
            this.btn43.ActiveCornerRadius = 20;
            this.btn43.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn43.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn43.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn43.BackColor = System.Drawing.SystemColors.Control;
            this.btn43.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn43.BackgroundImage")));
            this.btn43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn43.ButtonText = "ThinButton";
            this.btn43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn43.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn43.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn43.IdleBorderThickness = 1;
            this.btn43.IdleCornerRadius = 20;
            this.btn43.IdleFillColor = System.Drawing.Color.White;
            this.btn43.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn43.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn43.Location = new System.Drawing.Point(271, 272);
            this.btn43.Margin = new System.Windows.Forms.Padding(5);
            this.btn43.Name = "btn43";
            this.btn43.Size = new System.Drawing.Size(123, 79);
            this.btn43.TabIndex = 104;
            this.btn43.Tag = "a";
            this.btn43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn43.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn44
            // 
            this.btn44.ActiveBorderThickness = 1;
            this.btn44.ActiveCornerRadius = 20;
            this.btn44.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn44.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn44.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn44.BackColor = System.Drawing.SystemColors.Control;
            this.btn44.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn44.BackgroundImage")));
            this.btn44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn44.ButtonText = "ThinButton";
            this.btn44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn44.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn44.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn44.IdleBorderThickness = 1;
            this.btn44.IdleCornerRadius = 20;
            this.btn44.IdleFillColor = System.Drawing.Color.White;
            this.btn44.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn44.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn44.Location = new System.Drawing.Point(404, 272);
            this.btn44.Margin = new System.Windows.Forms.Padding(5);
            this.btn44.Name = "btn44";
            this.btn44.Size = new System.Drawing.Size(123, 79);
            this.btn44.TabIndex = 105;
            this.btn44.Tag = "a";
            this.btn44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn44.Click += new System.EventHandler(this.btn_Click);
            // 
            // btn45
            // 
            this.btn45.ActiveBorderThickness = 1;
            this.btn45.ActiveCornerRadius = 20;
            this.btn45.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btn45.ActiveForecolor = System.Drawing.Color.Transparent;
            this.btn45.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn45.BackColor = System.Drawing.SystemColors.Control;
            this.btn45.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn45.BackgroundImage")));
            this.btn45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn45.ButtonText = "ThinButton";
            this.btn45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn45.Font = new System.Drawing.Font("Century Gothic", 15F);
            this.btn45.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btn45.IdleBorderThickness = 1;
            this.btn45.IdleCornerRadius = 20;
            this.btn45.IdleFillColor = System.Drawing.Color.White;
            this.btn45.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btn45.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btn45.Location = new System.Drawing.Point(537, 272);
            this.btn45.Margin = new System.Windows.Forms.Padding(5);
            this.btn45.Name = "btn45";
            this.btn45.Size = new System.Drawing.Size(123, 79);
            this.btn45.TabIndex = 112;
            this.btn45.Tag = "a";
            this.btn45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn45.Click += new System.EventHandler(this.btn_Click);
            // 
            // turmas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "turmas";
            this.Size = new System.Drawing.Size(665, 560);
            this.Load += new System.EventHandler(this.turmas_Load);
            this.VisibleChanged += new System.EventHandler(this.turmas_VisibleChanged);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton rbMedio;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.RadioButton rbFund2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.RadioButton rbFund1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuThinButton2 btn52;
        private Bunifu.Framework.UI.BunifuThinButton2 btn51;
        private Bunifu.Framework.UI.BunifuThinButton2 btn53;
        private Bunifu.Framework.UI.BunifuThinButton2 btn55;
        private Bunifu.Framework.UI.BunifuThinButton2 btn54;
        private Bunifu.Framework.UI.BunifuThinButton2 btn11;
        private Bunifu.Framework.UI.BunifuThinButton2 btn12;
        private Bunifu.Framework.UI.BunifuThinButton2 btn13;
        private Bunifu.Framework.UI.BunifuThinButton2 btn14;
        private Bunifu.Framework.UI.BunifuThinButton2 btn15;
        private Bunifu.Framework.UI.BunifuThinButton2 btn21;
        private Bunifu.Framework.UI.BunifuThinButton2 btn22;
        private Bunifu.Framework.UI.BunifuThinButton2 btn23;
        private Bunifu.Framework.UI.BunifuThinButton2 btn24;
        private Bunifu.Framework.UI.BunifuThinButton2 btn25;
        private Bunifu.Framework.UI.BunifuThinButton2 btn35;
        private Bunifu.Framework.UI.BunifuThinButton2 btn34;
        private Bunifu.Framework.UI.BunifuThinButton2 btn33;
        private Bunifu.Framework.UI.BunifuThinButton2 btn31;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Bunifu.Framework.UI.BunifuThinButton2 btn32;
        private Bunifu.Framework.UI.BunifuThinButton2 btn41;
        private Bunifu.Framework.UI.BunifuThinButton2 btn42;
        private Bunifu.Framework.UI.BunifuThinButton2 btn43;
        private Bunifu.Framework.UI.BunifuThinButton2 btn44;
        private Bunifu.Framework.UI.BunifuThinButton2 btn45;


    }
}
