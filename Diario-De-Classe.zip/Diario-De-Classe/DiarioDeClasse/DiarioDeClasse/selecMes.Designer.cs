﻿namespace DiarioDeClasse
{
    partial class selecMes
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(selecMes));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnDezembro = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnJaneiro = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnNovembro = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnFevereiro = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnOutubro = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnSetembro = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAgosto = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnJulho = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnJunho = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnMarco = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAbril = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnMaio = new Bunifu.Framework.UI.BunifuThinButton2();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.btnDezembro, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnJaneiro, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnNovembro, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnFevereiro, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnOutubro, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnSetembro, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnAgosto, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnJulho, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnJunho, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMarco, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnAbril, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnMaio, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(15);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(665, 560);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Resize += new System.EventHandler(this.tableLayoutPanel1_Resize);
            // 
            // btnDezembro
            // 
            this.btnDezembro.ActiveBorderThickness = 1;
            this.btnDezembro.ActiveCornerRadius = 20;
            this.btnDezembro.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnDezembro.ActiveForecolor = System.Drawing.Color.White;
            this.btnDezembro.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnDezembro.BackColor = System.Drawing.SystemColors.Control;
            this.btnDezembro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDezembro.BackgroundImage")));
            this.btnDezembro.ButtonText = "Dezembro";
            this.btnDezembro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDezembro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDezembro.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnDezembro.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnDezembro.IdleBorderThickness = 1;
            this.btnDezembro.IdleCornerRadius = 20;
            this.btnDezembro.IdleFillColor = System.Drawing.Color.White;
            this.btnDezembro.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnDezembro.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnDezembro.Location = new System.Drawing.Point(457, 435);
            this.btnDezembro.Margin = new System.Windows.Forms.Padding(15);
            this.btnDezembro.Name = "btnDezembro";
            this.btnDezembro.Size = new System.Drawing.Size(193, 110);
            this.btnDezembro.TabIndex = 51;
            this.btnDezembro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDezembro.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnJaneiro
            // 
            this.btnJaneiro.ActiveBorderThickness = 1;
            this.btnJaneiro.ActiveCornerRadius = 20;
            this.btnJaneiro.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnJaneiro.ActiveForecolor = System.Drawing.Color.White;
            this.btnJaneiro.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnJaneiro.BackColor = System.Drawing.SystemColors.Control;
            this.btnJaneiro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJaneiro.BackgroundImage")));
            this.btnJaneiro.ButtonText = "Janeiro";
            this.btnJaneiro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJaneiro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnJaneiro.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnJaneiro.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnJaneiro.IdleBorderThickness = 1;
            this.btnJaneiro.IdleCornerRadius = 20;
            this.btnJaneiro.IdleFillColor = System.Drawing.Color.White;
            this.btnJaneiro.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnJaneiro.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnJaneiro.Location = new System.Drawing.Point(15, 15);
            this.btnJaneiro.Margin = new System.Windows.Forms.Padding(15);
            this.btnJaneiro.Name = "btnJaneiro";
            this.btnJaneiro.Size = new System.Drawing.Size(191, 110);
            this.btnJaneiro.TabIndex = 38;
            this.btnJaneiro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnJaneiro.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnNovembro
            // 
            this.btnNovembro.ActiveBorderThickness = 1;
            this.btnNovembro.ActiveCornerRadius = 20;
            this.btnNovembro.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnNovembro.ActiveForecolor = System.Drawing.Color.White;
            this.btnNovembro.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnNovembro.BackColor = System.Drawing.SystemColors.Control;
            this.btnNovembro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNovembro.BackgroundImage")));
            this.btnNovembro.ButtonText = "Novembro";
            this.btnNovembro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNovembro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNovembro.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnNovembro.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnNovembro.IdleBorderThickness = 1;
            this.btnNovembro.IdleCornerRadius = 20;
            this.btnNovembro.IdleFillColor = System.Drawing.Color.White;
            this.btnNovembro.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnNovembro.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnNovembro.Location = new System.Drawing.Point(236, 435);
            this.btnNovembro.Margin = new System.Windows.Forms.Padding(15);
            this.btnNovembro.Name = "btnNovembro";
            this.btnNovembro.Size = new System.Drawing.Size(191, 110);
            this.btnNovembro.TabIndex = 50;
            this.btnNovembro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnNovembro.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnFevereiro
            // 
            this.btnFevereiro.ActiveBorderThickness = 1;
            this.btnFevereiro.ActiveCornerRadius = 20;
            this.btnFevereiro.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnFevereiro.ActiveForecolor = System.Drawing.Color.White;
            this.btnFevereiro.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnFevereiro.BackColor = System.Drawing.SystemColors.Control;
            this.btnFevereiro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFevereiro.BackgroundImage")));
            this.btnFevereiro.ButtonText = "Fevereiro";
            this.btnFevereiro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFevereiro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnFevereiro.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnFevereiro.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnFevereiro.IdleBorderThickness = 1;
            this.btnFevereiro.IdleCornerRadius = 20;
            this.btnFevereiro.IdleFillColor = System.Drawing.Color.White;
            this.btnFevereiro.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnFevereiro.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnFevereiro.Location = new System.Drawing.Point(236, 15);
            this.btnFevereiro.Margin = new System.Windows.Forms.Padding(15);
            this.btnFevereiro.Name = "btnFevereiro";
            this.btnFevereiro.Size = new System.Drawing.Size(191, 110);
            this.btnFevereiro.TabIndex = 39;
            this.btnFevereiro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFevereiro.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnOutubro
            // 
            this.btnOutubro.ActiveBorderThickness = 1;
            this.btnOutubro.ActiveCornerRadius = 20;
            this.btnOutubro.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnOutubro.ActiveForecolor = System.Drawing.Color.White;
            this.btnOutubro.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnOutubro.BackColor = System.Drawing.SystemColors.Control;
            this.btnOutubro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOutubro.BackgroundImage")));
            this.btnOutubro.ButtonText = "Outubro";
            this.btnOutubro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOutubro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnOutubro.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnOutubro.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnOutubro.IdleBorderThickness = 1;
            this.btnOutubro.IdleCornerRadius = 20;
            this.btnOutubro.IdleFillColor = System.Drawing.Color.White;
            this.btnOutubro.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnOutubro.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnOutubro.Location = new System.Drawing.Point(15, 435);
            this.btnOutubro.Margin = new System.Windows.Forms.Padding(15);
            this.btnOutubro.Name = "btnOutubro";
            this.btnOutubro.Size = new System.Drawing.Size(191, 110);
            this.btnOutubro.TabIndex = 43;
            this.btnOutubro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOutubro.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnSetembro
            // 
            this.btnSetembro.ActiveBorderThickness = 1;
            this.btnSetembro.ActiveCornerRadius = 20;
            this.btnSetembro.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnSetembro.ActiveForecolor = System.Drawing.Color.White;
            this.btnSetembro.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnSetembro.BackColor = System.Drawing.SystemColors.Control;
            this.btnSetembro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSetembro.BackgroundImage")));
            this.btnSetembro.ButtonText = "Setembro";
            this.btnSetembro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSetembro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSetembro.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnSetembro.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnSetembro.IdleBorderThickness = 1;
            this.btnSetembro.IdleCornerRadius = 20;
            this.btnSetembro.IdleFillColor = System.Drawing.Color.White;
            this.btnSetembro.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnSetembro.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnSetembro.Location = new System.Drawing.Point(457, 295);
            this.btnSetembro.Margin = new System.Windows.Forms.Padding(15);
            this.btnSetembro.Name = "btnSetembro";
            this.btnSetembro.Size = new System.Drawing.Size(193, 110);
            this.btnSetembro.TabIndex = 44;
            this.btnSetembro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSetembro.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnAgosto
            // 
            this.btnAgosto.ActiveBorderThickness = 1;
            this.btnAgosto.ActiveCornerRadius = 20;
            this.btnAgosto.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnAgosto.ActiveForecolor = System.Drawing.Color.White;
            this.btnAgosto.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnAgosto.BackColor = System.Drawing.SystemColors.Control;
            this.btnAgosto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAgosto.BackgroundImage")));
            this.btnAgosto.ButtonText = "Agosto";
            this.btnAgosto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgosto.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAgosto.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnAgosto.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnAgosto.IdleBorderThickness = 1;
            this.btnAgosto.IdleCornerRadius = 20;
            this.btnAgosto.IdleFillColor = System.Drawing.Color.White;
            this.btnAgosto.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnAgosto.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnAgosto.Location = new System.Drawing.Point(236, 295);
            this.btnAgosto.Margin = new System.Windows.Forms.Padding(15);
            this.btnAgosto.Name = "btnAgosto";
            this.btnAgosto.Size = new System.Drawing.Size(191, 110);
            this.btnAgosto.TabIndex = 45;
            this.btnAgosto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAgosto.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnJulho
            // 
            this.btnJulho.ActiveBorderThickness = 1;
            this.btnJulho.ActiveCornerRadius = 20;
            this.btnJulho.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnJulho.ActiveForecolor = System.Drawing.Color.White;
            this.btnJulho.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnJulho.BackColor = System.Drawing.SystemColors.Control;
            this.btnJulho.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJulho.BackgroundImage")));
            this.btnJulho.ButtonText = "Julho";
            this.btnJulho.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJulho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnJulho.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnJulho.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnJulho.IdleBorderThickness = 1;
            this.btnJulho.IdleCornerRadius = 20;
            this.btnJulho.IdleFillColor = System.Drawing.Color.White;
            this.btnJulho.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnJulho.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnJulho.Location = new System.Drawing.Point(15, 295);
            this.btnJulho.Margin = new System.Windows.Forms.Padding(15);
            this.btnJulho.Name = "btnJulho";
            this.btnJulho.Size = new System.Drawing.Size(191, 110);
            this.btnJulho.TabIndex = 46;
            this.btnJulho.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnJulho.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnJunho
            // 
            this.btnJunho.ActiveBorderThickness = 1;
            this.btnJunho.ActiveCornerRadius = 20;
            this.btnJunho.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnJunho.ActiveForecolor = System.Drawing.Color.White;
            this.btnJunho.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnJunho.BackColor = System.Drawing.SystemColors.Control;
            this.btnJunho.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJunho.BackgroundImage")));
            this.btnJunho.ButtonText = "Junho";
            this.btnJunho.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnJunho.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnJunho.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnJunho.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnJunho.IdleBorderThickness = 1;
            this.btnJunho.IdleCornerRadius = 20;
            this.btnJunho.IdleFillColor = System.Drawing.Color.White;
            this.btnJunho.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnJunho.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnJunho.Location = new System.Drawing.Point(457, 155);
            this.btnJunho.Margin = new System.Windows.Forms.Padding(15);
            this.btnJunho.Name = "btnJunho";
            this.btnJunho.Size = new System.Drawing.Size(193, 110);
            this.btnJunho.TabIndex = 47;
            this.btnJunho.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnJunho.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnMarco
            // 
            this.btnMarco.ActiveBorderThickness = 1;
            this.btnMarco.ActiveCornerRadius = 20;
            this.btnMarco.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnMarco.ActiveForecolor = System.Drawing.Color.White;
            this.btnMarco.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnMarco.BackColor = System.Drawing.SystemColors.Control;
            this.btnMarco.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMarco.BackgroundImage")));
            this.btnMarco.ButtonText = "Março";
            this.btnMarco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMarco.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMarco.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnMarco.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnMarco.IdleBorderThickness = 1;
            this.btnMarco.IdleCornerRadius = 20;
            this.btnMarco.IdleFillColor = System.Drawing.Color.White;
            this.btnMarco.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnMarco.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnMarco.Location = new System.Drawing.Point(457, 15);
            this.btnMarco.Margin = new System.Windows.Forms.Padding(15);
            this.btnMarco.Name = "btnMarco";
            this.btnMarco.Size = new System.Drawing.Size(193, 110);
            this.btnMarco.TabIndex = 40;
            this.btnMarco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMarco.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnAbril
            // 
            this.btnAbril.ActiveBorderThickness = 1;
            this.btnAbril.ActiveCornerRadius = 20;
            this.btnAbril.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnAbril.ActiveForecolor = System.Drawing.Color.White;
            this.btnAbril.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnAbril.BackColor = System.Drawing.SystemColors.Control;
            this.btnAbril.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAbril.BackgroundImage")));
            this.btnAbril.ButtonText = "Abril";
            this.btnAbril.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAbril.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAbril.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnAbril.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnAbril.IdleBorderThickness = 1;
            this.btnAbril.IdleCornerRadius = 20;
            this.btnAbril.IdleFillColor = System.Drawing.Color.White;
            this.btnAbril.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnAbril.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnAbril.Location = new System.Drawing.Point(15, 155);
            this.btnAbril.Margin = new System.Windows.Forms.Padding(15);
            this.btnAbril.Name = "btnAbril";
            this.btnAbril.Size = new System.Drawing.Size(191, 110);
            this.btnAbril.TabIndex = 41;
            this.btnAbril.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAbril.Click += new System.EventHandler(this.mes_Click);
            // 
            // btnMaio
            // 
            this.btnMaio.ActiveBorderThickness = 1;
            this.btnMaio.ActiveCornerRadius = 20;
            this.btnMaio.ActiveFillColor = System.Drawing.Color.RoyalBlue;
            this.btnMaio.ActiveForecolor = System.Drawing.Color.White;
            this.btnMaio.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btnMaio.BackColor = System.Drawing.SystemColors.Control;
            this.btnMaio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaio.BackgroundImage")));
            this.btnMaio.ButtonText = "Maio";
            this.btnMaio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMaio.Font = new System.Drawing.Font("Century Gothic", 24F);
            this.btnMaio.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnMaio.IdleBorderThickness = 1;
            this.btnMaio.IdleCornerRadius = 20;
            this.btnMaio.IdleFillColor = System.Drawing.Color.White;
            this.btnMaio.IdleForecolor = System.Drawing.Color.RoyalBlue;
            this.btnMaio.IdleLineColor = System.Drawing.Color.RoyalBlue;
            this.btnMaio.Location = new System.Drawing.Point(236, 155);
            this.btnMaio.Margin = new System.Windows.Forms.Padding(15);
            this.btnMaio.Name = "btnMaio";
            this.btnMaio.Size = new System.Drawing.Size(191, 110);
            this.btnMaio.TabIndex = 42;
            this.btnMaio.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnMaio.Click += new System.EventHandler(this.mes_Click);
            // 
            // selecMes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "selecMes";
            this.Size = new System.Drawing.Size(665, 560);
            this.Load += new System.EventHandler(this.selecMes_VisibleChanged);
            this.VisibleChanged += new System.EventHandler(this.selecMes_VisibleChanged);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnJaneiro;
        private Bunifu.Framework.UI.BunifuThinButton2 btnFevereiro;
        private Bunifu.Framework.UI.BunifuThinButton2 btnMarco;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAbril;
        private Bunifu.Framework.UI.BunifuThinButton2 btnMaio;
        private Bunifu.Framework.UI.BunifuThinButton2 btnJunho;
        private Bunifu.Framework.UI.BunifuThinButton2 btnJulho;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAgosto;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSetembro;
        private Bunifu.Framework.UI.BunifuThinButton2 btnOutubro;
        private Bunifu.Framework.UI.BunifuThinButton2 btnNovembro;
        private Bunifu.Framework.UI.BunifuThinButton2 btnDezembro;

    }
}
